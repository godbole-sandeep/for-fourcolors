int Add(int u, int v);

int main() {
	int result = 0;
	result = 3 + 5; // Try to step into (press F11) expression
	result = Add(1, 2); // Try to step into (press F11) expression
	return 0;
}

int Add(int u, int v) {
	return u + v;
}

/*
What is the key point to note in the program above?
- When we attempt to step into the expression, the step into doesn't happen,
  but the expression executes. Hence, the expression is considered as inline.
- When we attempt to step into the 'Add' function, the step into happens.
- The control temporarily leaves 'main' and goes into the 'Add' function.
- Hence, the Add function is not inline.
*/