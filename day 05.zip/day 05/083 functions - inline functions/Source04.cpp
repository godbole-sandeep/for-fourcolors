#define MIN(i, j)(i < j ? i : j)

inline int min(int i, int j) {
	return (i < j ? i : j);
}

int main() {
	int a = 1, b = 2, c = 0;
	c = MIN(++a, ++b); // a = 2, b = 3, c = 2

	int u = 1, v = 2, w = 0;
	w = min(++u, ++v); // u = 2, v = 3, w = 2

	return 0;
}

/*
What is the key point to note in the program above?
- The program uses both a macro and an inline function.
- Inline functions are type-safe compared to macros.
- Macros are used specifically when code substitution is desired.

How macros are different from inline functions?
- Macros are expanded by the preprocessor.
- Inline functions are expanded during the compilation phase.
- If an expression such as '++a' is passed to a macro, the expression is
  substituted as is, whereas in the case of an inline function, the result
  of the expression is substituted, not the expression itself.
- The parameters of a macro function do not have data types, whereas inline
  function parameters have data type specifications.
- Hence, inline functions are type-safe compared to macros.
*/