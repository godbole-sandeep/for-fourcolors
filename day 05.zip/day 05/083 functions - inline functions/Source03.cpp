#include "api.h"

int main() {
	int result = 0;
	result = 3 + 5;
	result = Add(1, 2);
	return 0;
}

/*
What is the key point to note in the program above?
- If a function is inline, its declaration and definition must be in a header file.
- A linking error occurs if the inline function definition is not included in the
  header file.
- For non-inline functions, the definition should never be kept in a header file,
  as this will cause a linking error. Only the declaration should be included in
  the header file for non-inline functions.
*/