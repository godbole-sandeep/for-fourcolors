inline int Add(int u, int v);

int main() {
	int result = 0;
	result = 3 + 5; // Try to step into (press F11) expression
	result = Add(1, 2); // Try to step into (press F11) expression
	return 0;
}

inline int Add(int u, int v) {
	return u + v;
}

/*
What is the key point to note in the program above?
- The 'Add' function is now written with the 'inline' keyword.
- 'inline' is a feature of C++.

What happens when a function is declared as inline?
-The C++ compiler replaces the call with the definition of the inline function.

Is inline an order or a request to the compiler?
- It is a request to the compiler.
- If the compiler deems it infeasible to inline the call, it won't inline the call.

So, when does the compiler not inline the call?
- The compiler may choose not to inline a function call in several situations:
  if the function is too complex or large, recursive, virtual, or if the definition
  of the function is not available at the time of compilation.
*/