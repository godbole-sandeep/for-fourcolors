#pragma once

inline int Add(int u, int v);

inline int Add(int u, int v) {
	return u + v;
}