#include <iostream>

extern "C" int Add(int u, int v);

int main() {
    int a = 1, b = 2, c = 0;
    c = Add(a, b);
    std::cout << "Result of addition: " << c << std::endl;
    return 0;
}

/*
Does the code link successfully?
- The code now linked successfully.

What does extern "C" accomplish?
- 'extern "C"' tells the C++ compiler to use C linkage for the specified
  function or functions.
- This prevents name mangling, ensuring that the function names are not
  modified by the compiler and remain consistent with their names in C.
- This allows C++ code to link with C functions correctly, ensuring
  compatibility between the two languages.

When is this useful?
- This is particularly useful when interfacing libraries written in C with C++ code.
*/