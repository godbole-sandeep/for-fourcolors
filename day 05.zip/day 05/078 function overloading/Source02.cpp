#include <cstdlib>

int GetRandomNumber() {
    return rand();
}

double GetRandomNumber() {
    return rand() / RAND_MAX;
}

/*
Can functions be overloaded based on return type differences only?
- No.
*/