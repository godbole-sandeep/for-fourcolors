#include <iostream>

#define PI 3.14159 

double CalculateArea(double radius);
double CalculateArea(double length, double width);

int main() {
    double length = 4.0, width = 6.0;
    double area = CalculateArea(length, width);

    std::cout << "Area of rectangle with length " << length
        << " and width " << width << ": " << area << std::endl;

    double radius = 3.0;
    area = CalculateArea(radius);

    std::cout << "Area of circle with radius " << radius
        << ": " << area << std::endl;

    return 0;
}

double CalculateArea(double radius) {
    return PI * radius * radius;
}

double CalculateArea(double length, double width) {
    return length * width;
}


/*
What is the key point to note in the program above?
- Note that there are two functions with the same name, 'CalculateArea'.
- This is possible in C++ and is called function overloading.

What is function overloading?
- Function overloading is a feature that allows you to define multiple functions
  with the same name, provided they have different parameter lists.

How does the compiler decide which function to call?
- It is based on the arguments passed to the function.

How does the compiler implement the function overloading feature?
- It uses name mangling to implement the function overloading feature.

What is name managling?
- Using the name mangling technique, compilers modify the names of functions and variables.
- This is also called name decoration.

Which factors are taken into account while mangling the name?
- When mangling names, compilers typically take into account several factors,
  such as the function name, the number, order, and types of the parameters,
  namespaces, class/struct name, calling conventions, etc.
*/