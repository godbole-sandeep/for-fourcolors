int Add(int p1, int p2, int p3 = 2, int p4 = 1, int p5 = 5, int p6 = 3);

int main() {
	int result = 0;
	result = Add(1, 2, , , , 4); // Error
	result = Add(1, 2, 2, 1, 5, 4);
	return 0;
}

int Add(int p1, int p2, int p3, int p4, int p5, int p6) {
	return p1 + p2 + p3 + p4 + p5 + p6;
}

/*
What are the key points to note in the program above?
- A function can have one or more optional parameters.
- They should all appear after the mandatory parameters.
- If we wish to provide a specific value to an optional
  parameter further down the list, it is necessary to
  give arguments (even default ones) to all optional
  parameters in between.
- Using empty commas to represent default arguments in
  those positions is not supported.
*/