int Add(int u, int v = 0);
int Add(int u, int v = 0, int w = 0);

int main() {
	int result = 0;
	result = Add(2, 3);
	return 0;
}

int Add(int u, int v) {
	return u + v;
}

int Add(int u, int v, int w) {
	return u + v + w;
}

/*
What is the key point to note in the program above?
-  The code results in ambiguity.
*/