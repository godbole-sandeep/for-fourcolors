int Add(int u, int v = 0);

int main() {
	int result = 0;
	result = Add(1, 2);
	result = Add(5);
	return 0;
}

int Add(int u, int v) {
	return u + v;
}

/*
What is the key point to note in the program above?
- The default argument is specified in the function declaration,
  but not in the definition.
- This is how it should be.
*/