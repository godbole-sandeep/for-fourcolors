int Add(int u, int v = 0) {
	return u + v;
}

int main() {
	int result = 0;
	result = Add(1, 2);
	result = Add(5); // the call is compiled as Add(5, 0);
	return 0;
}

/*
What is the key point to note in the program above?
- Note the value assigned to the second parameter of the `Add` function.
- This is the default value given to the second parameter.
- It is known as a default argument.
- Assigning a default value to the parameter makes that parameter optional.
- If no argument is provided for that parameter in the call, the default value is used.
- If a specific argument is provided for that parameter in the call, that value is used.
*/
