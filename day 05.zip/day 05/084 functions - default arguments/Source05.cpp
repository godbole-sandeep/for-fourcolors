int Add(int u = 0, int v);

int main() {
	int result = 0;
	result = Add(1, 2);
	result = Add(5);
	return 0;
}

int Add(int u, int v) {
	return u + v;
}

/*
Why does the compiler fail to compile the code?
- The compiler fails to compile the code because, default arguments
  must be specified from right to left, meaning all parameters to
  the right of a parameter with a default argument must also have
  default arguments.
- In this case, 'u' has a default argument, but 'v' does not, which
  is not allowed.
- To fix this, either both parameters should have default arguments, or
  the default argument should be moved to the rightmost parameter.
*/