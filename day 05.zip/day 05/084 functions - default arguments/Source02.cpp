int Add(int u, int v);

int main() {
	int result = 0;
	result = Add(1, 2);
	result = Add(5);
	return 0;
}

int Add(int u, int v = 0) {
	return u + v;
}

/*
Why does the compiler fail to compile the code?
- The code fails to compile because the default argument for the 'Add' function should be
  specified in the function declaration, not in the definition.
- Since the default argument is not included in the declaration of 'Add',
  the compiler does not recognize that 'v' should have a default value when
  'Add' is called with a single argument.
- To fix this, move the default argument to the function declaration.
*/
