int Add(int u, int v = 0);

int main() {
	int result = 0;
	result = Add(1, 2);
	result = Add(5);
	return 0;
}

int Add(int u, int v = 0) {
	return u + v;
}

/*
Why does the compiler fail to compile the code?
- The code throws a compilation error because default arguments should
  only be specified once, typically in the function declaration (prototype),
  not in both the declaration and the definition.
- In this case, the default argument for v is redundantly specified in both
  the declaration and the definition of the Add function, which is not allowed.
- To resolve this, the default argument should be provided only in the function
  declaration.
*/
