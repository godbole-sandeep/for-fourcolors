#include <iostream>

extern "C" {
    int Add(int u, int v);
}

int main() {
    int a = 1, b = 2, c = 0;
    c = Add(a, b);
    std::cout << "Result of addition: " << c << std::endl;
    return 0;
}

/*
What is the key point to note in the program above?
- The code is the same as before, except that an extern "C" block is used
  instead of writing extern "C" in the function prototype.
- 'extern "C"' block facilitates prevention of name mangling for multiple function
  declarations.
*/