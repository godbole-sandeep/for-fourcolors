#include <iostream>

int Add(int u, int v);

int main() {
    int a = 1, b = 2, c = 0;
    c = Add(a, b);
    std::cout << "Result of addition: " << c << std::endl;
    return 0;
}

/*
Why does program fail to link?
- The program fails to link because of naming convetion and name mangling differences
  between C and C++ compilers.
- Use 'dumpbin.exe' to observe the difference.
*/