#pragma once

int Add(int u, int v) {
	return u + v;
}