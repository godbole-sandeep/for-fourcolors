#pragma once

#ifdef __cplusplus
extern "C" {
#endif

	int Add(int u, int v);

#ifdef __cplusplus
}
#endif