#include <iostream>

#include "api.h"

int main() {
    int a = 1, b = 2, c = 0;
    c = Add(a, b);
    std::cout << "Result of addition: " << c << std::endl;
    return 0;
}

/*
What is the key point to note in the program above?
- 'extern "C"' blocks are often written in header files rather than in source files.
- The 'extern "C"' block has been moved to 'api.h'.
*/