long Factorial(int n);

int main() {
	int result = 0;
	result = Factorial(3);
	return 0;
}

long Factorial(int n) {
	if (n == 1)
		return 1;
	return n * Factorial(n - 1);
}

/*
What is the key point to note in the program above?
- The program demonstrates a recursive way of computing the Factorial.

What is a recursive function?
- A recursive function is a function that calls itself.

What is the threat to a recursive function?
- The primary threat to a recursive function is the risk of infinite recursion.
- This can lead to a stack overflow, where the call stack runs out of memory,
  causing the program to crash.
*/