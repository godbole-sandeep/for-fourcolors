struct Point {
	int x;
	int y;
};

struct EmptyStruct {};

struct Record {
	int n;
	char ch;
};

/*
What is the size of an empty struct in C++?
- The size of an empty struct in C++ is 1 byte.

What is padding in a 'struct'?
- In theory, the size of a 'struct' equals the total of the sizes of each of its data members.
- However, in practice, it may be larger than the theoretically calculated size.
- This is because compilers may include padding bytes to improve performance.
- Padding in a 'struct' refers to the extra memory added between members to align data structures
  according to the alignment requirements of the architecture.
- It helps optimize access speed and ensures that data is stored in memory efficiently.
- Therefore, you should not rely on manually calculated theoretical sizes of a 'struct'.
- Always use the 'sizeof' operator to determine the actual size of a 'struct' or 'struct' variable.
*/
