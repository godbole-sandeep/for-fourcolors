#include <iostream>

struct Point {
    int x;
    int y;
};

void OffsetPoint(Point& p, int offsetX, int offsetY); 

int main() {
    Point a = { -1, 1 };

    std::cout << "Original Point: x = " << a.x << ", y = " << a.y << std::endl;

    OffsetPoint(a, 3, -2);

    std::cout << "Shifted Point: x = " << a.x << ", y = " << a.y << std::endl;

    return 0;
}

void OffsetPoint(Point& p, int offsetX, int offsetY) {
    p.x += offsetX;
    p.y += offsetY;
}