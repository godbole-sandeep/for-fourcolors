
/*
What is the key point to note in the program above?
- The program illustrates reference to a struct variable.
*/