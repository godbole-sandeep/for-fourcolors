

/*
What is a struct?
- A struct is a user-defined data type that allows grouping variables of different types under a single name.
- For example, 'Point' is a user-defined data type, commonly known as a UDT.

What are data members?
- Data members are variables that are declared within a struct.
- For example, 'x' and 'y' are data members.

What is the scope of struct Point?
- Since struct 'Point' is defined outside of function, it has global scope.

Can multiple variables of a 'struct' be defined in the same statement?
- Yes, Line 10 illustrates this.

How do you access the data members of a 'struct'?
- To access the data members of a struct,
  1. Use the dot operator (.) when you have an instance of a struct.
     Lines 12, 13, and 14 illustrate this.
  2. Use the arrow operator (->) when you have a pointer to an instance of a struct.
     Lines 17, 18, and 20 illustrate this.

How do you assign instances of the same struct type to each other?
- Instances of the same struct type can be assigned directly.
- All data members are copied from the source instance to the destination instance.
- Line 30, illustrates this.

how do you assign instances of different struct types to each other?
- Instances of different struct types cannot be assigned directly.
- Instead, you must manually assign each data member from one struct to another.
- Line 35, and 36 illustrate this.
*/