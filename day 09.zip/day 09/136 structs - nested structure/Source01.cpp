
/*
What is the key point to note in the program above?
- A struct can be declared within another struct.
- Such relationship is called as nested struct relationship.
- A structure can nest within another structure.
*/