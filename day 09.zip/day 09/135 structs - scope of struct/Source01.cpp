
/*
What is the key point to note in the program above?
- When a structure is declared locally within a function,
  it is only accessible to that function.
- To make a struct available to other functions, it needs to be declared globally.
- Typically, structs are declared in a header file, which is then included at the top of the .cpp file.
*/