
/*
What is the key point to note in the program above?
- A point object is dynamically allocated on the freestore, manipulated, and then released.
*/