
/*
What is the key point to note in the program above?
- An array of point objects is dynamically allocated on the freestore, manipulated, and then released.
*/