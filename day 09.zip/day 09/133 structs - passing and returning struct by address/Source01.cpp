
/*
What is the key point to note in the program above?
- In this program, we pass and return structures by address.
- This is the preferred approach.
- We choose to specify a pointer referring to a const structure
  if the function is only going to read the data.
- Declaring a pointer to const makes the function more adaptable.
- If a function's objective is to modify the original object,
  we omit specifying const on the pointer.*/