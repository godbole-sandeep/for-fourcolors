
/*
What is the key point to note in the program above?
- In this program, we pass and return structures by reference.
- This is another preferred approach.
- Declare a const reference to a structure when the function will only read its values.
- By specifying a const reference, the function gains versatility.
- If a function's objective is to modify the original object,
  it is not necessary to specify the reference as const.
*/