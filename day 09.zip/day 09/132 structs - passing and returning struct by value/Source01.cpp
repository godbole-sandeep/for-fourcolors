
/*
What is the key point to note in the program above?
- In this program, we pass and return a structure by value.
- Generally, we avoid passing large structures by value because it requires
  more memory and can contain redundant information.
*/