
/*
What is the key point to note in the program above?
- The example above demonstrates multiple interface inheritance.
*/
