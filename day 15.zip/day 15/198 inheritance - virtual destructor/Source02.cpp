
/*
What is the key point to note in the program above?
- With a base class virtual destructor, the derived class destructor gets called first and then the base class destructor.
- This ensures that all resources allocated by the derived class are properly cleaned up before the base class resources are released.
- Therefore, it is strongly recommended to have virtual destructor in the base class.
*/