
/*
What is the key point to note in the program above?
- When you delete an object through a pointer to a base class, if the base class destructor is not virtual,
  only the base class destructor gets called.
- This might lead to resource leaks if the derived class has allocated resources that need to be deallocated.
*/