
/*
What is the key point to note in the program above?
- When a class inherits from two classes that have a common base class,
  it lead to ambiguity in the inheritance hierarchy, especially when the
  common base's methods or attributes are referred using an object.
*/
