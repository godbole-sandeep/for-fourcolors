
/*
What is an interface?
- An interface defines a contract specifying a set of methods or functions that a class must implement.
- By implementing the interface, a class promises to provide the specified functionality.
- Every interface is an abstract class, but not every abstract class is an interface.
- In Microsoft environments, interfaces are typically named using the "I" prefix followed by a descriptive
  name. For example, IUnknown, IDisposable, IStream.

Can a class implement multiple interfaces?
- Yes, a class can implement multiple interfaces, allowing it to inherit behavior from multiple sources.

Besides abstract methods, what other members can an interface have?
- An interface should not have any other members except abstract functions and, optionally, a virtual
  destructor.

Can an interface contain data members?
- No, an interface should not contain any data members, only abstract functions and, optionally, a virtual
  destructor.
*/