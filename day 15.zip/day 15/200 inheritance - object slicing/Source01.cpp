
/*
What is object slicing?
- Object slicing is a situation where a derived class object is assigned to a base class
  object, resulting in the loss of derived class-specific attributes and behaviors.
*/