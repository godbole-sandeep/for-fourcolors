
/*
What is polymorphism?
- Polymorphism is the ability of different objects to respond to the same message in different ways.

What are the types of polymorphisms?
- Compile-time Polymorphism. And,
- Run-time Polymorphism.

What is compile-time polymorphism?
- Compile-time polymorphism, also known as static polymorphism, refers to function overloading
  and operator overloading.

What is run-time polymorphism?
- Run-time polymorphism, also known as dynamic polymorphism, refers to the ability of a program
  to decide which method to execute at runtime, rather than at compile time.
- Run-time polymorphism is enabled by the combination of virtual functions and base pointer/reference.
*/