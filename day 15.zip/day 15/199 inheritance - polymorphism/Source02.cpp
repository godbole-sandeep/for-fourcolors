
/*
What is the key point to note in the program above?
- Run-time polymorphism is enabled by the combination of virtual functions and base pointer/reference.
*/