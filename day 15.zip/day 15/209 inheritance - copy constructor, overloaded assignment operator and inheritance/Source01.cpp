
/*
What are the key points to note in the program above?
- The default constructor of a derived class calls the default constructor of the base class.
- The copy constructor of a derived class calls the copy constructor of the base class.
- The parametric constructor of a derived class calls the parametric constructor of the base class.
- The assignment operator of a derived class calls the assignment operator of the base class.
*/