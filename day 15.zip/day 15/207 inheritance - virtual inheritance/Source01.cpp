
/*
What is virtual inheritance?
- Virtual inheritance ensures that a base class is inherited only once by any derived class,
  even if multiple paths lead to the same base class.
- This prevents the duplication of base class members.
*/