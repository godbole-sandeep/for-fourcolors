
/*
What is multiple inheritance?
- Multiple inheritance occurs when a class inherits attributes and methods from more than one base class.

What is the key point to note in the program above?
- When you create an object of the derived class, it contains all the data members from both Base1
  and Base2, as well as its own data members.

What are the types of multiple inheritance?
- Multiple inheritance can be of two types: multiple class inheritance and multiple interface inheritance.
- The example above demonstrates multiple class inheritance.
*/