
/*
What is an abstract class?
- An abstract class is a class that contains one or more abstract (pure virtual) functions.

Besides abstract functions, what other members can an abstract class have?
- An abstract class can have various types of members, including constructors, destructors,
  overloaded operators, setters, getters, impure virtual functions, and non-virtual functions,
  in addition to pure virtual functions.

Can an abstract class be instantiated?
- No, an abstract class cannot be instantiated.

What does an abstract class represent?
- Logically, an abstract class represents a conceptual entity or an incomplete/partial
  implementation. For example, Shape is a conceptual entity, while Circle is a real entity.
*/