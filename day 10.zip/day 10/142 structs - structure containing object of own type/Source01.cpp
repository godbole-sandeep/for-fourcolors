
/*
Can a struct contain an object of its own type as a member?
- A struct cannot contain an object of its own type directly because
  it would lead to an infinite recursion in memory allocation.
*/