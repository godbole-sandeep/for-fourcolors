
/*
Can a struct contain a pointer of other type as a member?
- Yes.
- For example, the struct Computer contains a pointer to a Keyboard as one of its members.
*/