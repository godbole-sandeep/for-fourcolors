
/*
Can a struct contain a pointer of its own type as a member?
- A struct can include a pointer to its own type.
- This breaks the recursion because a pointer has a fixed size, regardless of the type it points to.
- This is commonly used in data structures like linked lists.
*/