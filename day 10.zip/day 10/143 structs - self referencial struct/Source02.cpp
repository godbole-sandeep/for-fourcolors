#include <iostream>

struct Node {
	int Data;
	Node* Next;
};

// Function to add a node at the end of the linked list
void Append(Node*& head, int value) {
	Node* newNode = new Node;
	newNode->Data = value;
	newNode->Next = nullptr;

	if (head == nullptr) {
		head = newNode;
		return;
	}

	Node* temp = head;
	while (temp->Next != nullptr) {
		temp = temp->Next;
	}
	temp->Next = newNode;
}

// Function to traverse and print the elements of the linked list
void Traverse(Node* head) {
	Node* temp = head;
	while (temp != nullptr) {
		std::cout << temp->Data << " ";
		temp = temp->Next;
	}
	std::cout << std::endl;
}

// Function to remove a node by value from the linked list
void Remove(Node*& head, int value) {
	Node* temp = head;
	Node* prev = nullptr;

	// Traverse the list to find the node to be removed
	while (temp != nullptr && temp->Data != value) {
		prev = temp;
		temp = temp->Next;
	}

	// If node with the given value is found, remove it
	if (temp != nullptr) {
		if (prev == nullptr) {
			head = temp->Next;
		}
		else {
			prev->Next = temp->Next;
		}
		delete temp;
	}
}

// Function to free the memory allocated for the linked list
void ClearList(Node*& head) {
	Node* temp = head;
	while (temp != nullptr) {
		Node* nextNode = temp->Next;
		delete temp;
		temp = nextNode;
	}
	head = nullptr;
}

int main() {
	Node* head = nullptr; // Initialize the head pointer to nullptr

	// Add some nodes to the linked list
	Append(head, 1);
	Append(head, 2);
	Append(head, 3);
	Append(head, 4);

	// Print the linked list
	std::cout << "Linked list: ";
	Traverse(head);

	// Remove a node with value 3 from the linked list
	Remove(head, 3);

	// Print the linked list after removal
	std::cout << "Linked list after removal: ";
	Traverse(head);

	// Free the memory allocated for the linked list
	ClearList(head);

	return 0;
}