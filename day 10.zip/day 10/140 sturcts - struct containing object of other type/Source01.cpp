
/*
Can a struct contain an object of other type as a member?
- Yes.
- For example, the struct Computer contains objects of CPU and Memory as its members.
*/