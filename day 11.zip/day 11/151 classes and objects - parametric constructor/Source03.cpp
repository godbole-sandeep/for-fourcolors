
/*
- There are three ways to call a parametric constructor if it is single parametric.
- If it is multi-parametric then only Method 1 and Method 2 can be used.
  The arguments are separated by comma. For ex. Rectangle r(1, 1, 5, 5); or
  Rectangle r = { 1, 1, 5, 5 };
*/