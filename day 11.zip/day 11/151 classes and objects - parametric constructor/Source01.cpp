#include <assert.h>
#include <iostream>
#include <stdexcept>

class Circle {
private:
	int m_radius;
public:
	int GetRadius() {
		assert(m_radius > 0);
		return m_radius;
	}

	void SetRadius(int radius) {
		if (radius <= 0)
			throw std::invalid_argument("Radius must be positive number.");
		m_radius = radius;
	}
public:
	void Print() {
		assert(m_radius > 0);
		std::cout << m_radius << std::endl;
	}
};

int main() {
	return 0;
}

/*
What is the key point to note in the program above?
- The Circle class has been written with a parameterized constructor.
- There are three ways to call a parametric constructor if it is single parametric.
- If it is multi-parametric then only Method 1 and Method 2 can be used.
  The arguments are separated by comma. For ex. Rectangle r(1, 1, 5, 5); or
  Rectangle r = { 1, 1, 5, 5 };
*/