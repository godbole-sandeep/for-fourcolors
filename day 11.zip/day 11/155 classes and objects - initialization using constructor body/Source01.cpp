class Integer {
public:
	Integer(int i) {
		m_i = i;
	}
private:
	int m_i;
};

int main() {
	Integer a(5);
	return 0;
}

/*
What is the key point to note in the program above?
- The data member(s) can be initialized within the constructor body.
*/