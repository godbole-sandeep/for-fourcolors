
/*
- The data member(s) can be initialized within the constructor body.
*/