
/*
- 'Print' and 'GetArea' are both operations.
*/