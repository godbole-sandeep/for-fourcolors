
/*
- C++ has introduced two keywords: private and public.
- They are known as access specifiers.
- The private access specifier prohibits direct access to the member.
- The public access specifier allows direct access to the member.
- Since m_radius is declared private, direct initialization or assignment is not allowed.
- Once an access specifier (public or private) is defined in the struct,
  all following members have the same access until it is altered by
  another access specifier.
- It is recommended to make data members private.
- Member functions may be private or public.
- Private access establishes a logical border around an object's private data members.
*/