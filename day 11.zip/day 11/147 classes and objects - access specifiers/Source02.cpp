
/*
- A developer can access private members of a struct through its public interface.
- Applications must use the public interface to modify an object's state.
*/