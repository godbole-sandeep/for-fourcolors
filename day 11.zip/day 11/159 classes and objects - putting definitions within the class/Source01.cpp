#include <assert.h>
#include <iostream>
#include <stdexcept>

#define PI 3.14

class Circle {
private:
	int m_radius;
public:
	Circle(int radius) {
		SetRadius(radius);
	}
public:
	int GetRadius() {
		assert(m_radius > 0);
		return m_radius;
	}

	void SetRadius(int radius) {
		if (radius <= 0)
			throw std::invalid_argument("Radius must be positive number.");
		m_radius = radius;
	}
public:
	void Print() {
		assert(m_radius > 0);
		std::cout << m_radius << std::endl;
	}

	double GetArea() {
		assert(m_radius > 0);
		return PI * m_radius * m_radius;
	}
};

int main() {
	Circle a(5);
	a.Print();
	std::cout << a.GetArea() << std::endl;
	return 0;
}

/*
What are the key points to note in the program above?
- Member functions defined within a class are inline by default.
- Comment out assertions to observe the inline effect of member functions.
- `inline` is a request to the compiler.
- Inlining may not be guaranteed by the compiler for complex functions, virtual functions,
  recursive functions, functions with static variables, or functions with exception handling.
*/
