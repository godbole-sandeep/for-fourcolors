class Integer {
private:
	int m_value;
public:
	Integer() {
		m_value = 0;
	}
};

int main() {
	// The default constructor is called automatically.
	Integer u;

	// Attempting to call the constructor explicitly.
	u.Integer();

	return 0;
}

/*
What is the key point to note in the program above?
- A constructor cannot be called explicitly.
- Attempting to call a constructor explicitly causes a compilation error.
- It is called once and only once when an object is defined.
- For the same object, it cannot be called twice.
- However, it is called for each new object.
*/