
/*
- Constructor cannot be called explicitly.
- Attempting to call constructor explicitly causes a compilation error.
- It is called once and only once, when an object is defined.
- For the same object, it cannot be called twice.
- But it's called for each new object.
*/