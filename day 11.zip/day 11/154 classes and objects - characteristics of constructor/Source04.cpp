#include <iostream>

class Integer {
private:
	int m_value;
public:
	Integer() {
		m_value = 0;
		std::cout << "The default constructor is called." << std::endl;
	}
};

int main() {
	Integer u; // constructor is called
	
	Integer* pu = &u; // constructor is not called
	
	Integer& ru = u; // constructor is not called

	return 0;
}

/*
Is the constructor called when an object is created?
- Yes, the constructor is called when an object is created.
- It initializes the object at the time of its creation.

Is the constructor called when a pointer or reference is created?
- No, the constructor is not called when a pointer or reference is created.

Why is the constructor not called for a pointer?
- The constructor is not called for a pointer because a pointer itself is not an object;
  it points to an object.

Why is the constructor not called for a reference?
- When you declare a reference, you are not creating a new object but rather providing
  an alternative name for an existing object.
- Since no new object is being created, there is no need to call a constructor.
*/