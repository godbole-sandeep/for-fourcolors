class Integer {
private:
	int m_value;
private:
	Integer() {
		m_value = 0;
	}
public:
	Integer(int value) {
		m_value = value;
	}
};

int main() {
	Integer u; // Error because default constructor is private
	Integer v(5); // Ok because parametric constructor is public
	return 0;
}

/*
What is the key point to note in the program above?
- If a constructor is declared private, it cannot be used to instantiate the class.
*/