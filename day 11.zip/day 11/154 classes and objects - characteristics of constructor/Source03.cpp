
/*
- Note that the constructor is called only for an object
  and not for pointer or reference.
- Since constructor is not called for pointer and reference,
  the destructor is also not called.
- Why is the constructor not called for a pointer?
  Remember, a pointer is not an object. It points to an object.
  Hence since it is not an object in itself, constructor is not called.
- Why is the constructor not called for reference?
  Reference refers to referent. Since constructor is already called for
  referent, there is no need to call constructor for the reference.
*/