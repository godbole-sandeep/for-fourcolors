
/*
- If a constructor is declared private, it cannot be used to instantiate the class.
*/