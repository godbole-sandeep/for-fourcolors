class Integer {
private:
	int m_value;
public:
	Integer() {

	}
};

int main() {
	Integer u;
	return 0;
}

/*
- Run the code step by step and observe the state of the Integer object in the local window
  after the constructor call.

Why does the object remain uninitialized?
- The object remains uninitialized because the default constructor does not initialize
  the member variable m_value.
- In the default constructor, no value is assigned to m_value, so it retains whatever value
  happens to be in the memory allocated for it, resulting in an uninitialized state.
- Thus, simply writing a constructor in a class is not enough to initialize an object.
- You need to write code that initializes the object's data members.
- The constructor provides an opportunity for you to initialize the object.
*/