
/*
- The parametric constructor's parameters may be set to default values.
- In such a case, constructor overloading is simulated by a
  single parametric constructor.
*/