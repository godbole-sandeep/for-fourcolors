int globalVariable = 0;

class Integer {
public:
	Integer(int i) : m_i(i), globalVariable(5) {
		m_i = i;
	}
private:
	int m_i;
};

int main() {
	Integer a(5);
	return 0;
}

/*
What are the key points to note in the program above?
- The initialization list can only be used to initialize data members.
- It cannot be used to initialize local, global, or static variables.
- Prefer the initialization list over initialization within the constructor body.
*/