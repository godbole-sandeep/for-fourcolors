
/*
- The initialization list can only be used to initialize data members.
- It cannot be used to initialize local, global or static data member variables.
- Prefer initialization list over initialization using constructor body.
*/