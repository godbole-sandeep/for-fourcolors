#include <stdlib.h>

class Integer {
private:
	int m_i;
public:
	Integer() : m_i(GetRandomInteger()) {}
public:
	void SetI(int i) {
		m_i = i;
	}

	int GetRandomInteger() {
		return rand();
	}
};

int main() {
	Integer a;
	return 0;
}

/*
Why the program compliles successfully?
- The program compiles successfully because the member initializer list directly initializes
  the member variable 'm_i' using the 'GetRandomInteger' function.
- Although 'GetRandomInteger' is a member function, it is called correctly within the member
  initializer list, ensuring that 'm_i' is properly initialized when an 'Integer' object is created.
*/