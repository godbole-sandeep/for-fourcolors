class Integer {
private:
	int m_i;
public:
	Integer(int i) : m_i(i) {}
public:
	void SetI(int i) : m_i(i) {}
};

int main() {
	Integer a(5);
	return 0;
}

/*
What is the key point to note in the program above?
- The initializer list can only be used in the constructor.
*/
