
/*
- Note, if you are using function to initialize data member in initialization list
  then the function must return a value and that value must be consumed to initialize
  the data member. Mere call to a function is not allowed.
*/