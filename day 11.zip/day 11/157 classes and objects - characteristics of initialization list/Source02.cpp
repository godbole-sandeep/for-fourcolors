class Integer {
private:
	int m_i;
public:
	Integer(int i) : SetI(i) {}
public:
	void SetI(int i) {
		m_i = i;
	} 
};

int main() {
	Integer a(5);
	return 0;
}

/*
Why does the program fail to compile??
- This code produces an error because the member initializer list is incorrectly trying to call
  a member function (SetI) instead of directly initializing the data member (m_i). 
- The member initializer list should be used to directly initialize member variables,
  not to call member functions.
*/