#include "Circle.h"

int main() {
	const Circle a = 5;
	int r = a.GetRadius(); // Step into GetRadius and check if control is going to GetRadius
	a.Print(); // Step into Print and check if control is going to Print
	double area = a.GetArea(); // Step into GetArea and check if control is going to GetArea
	return 0;
}

/*
What are the key points to note in the program above?
- Declaring a member function with the 'const' keyword indicates that it is
  a "read-only" function, meaning it does not modify the object's state.
- To declare a member function as a 'const' member function, add 'const' after
  the parameter list in both the declaration and the definition.*/