
/*
- Object space contains only data members.
- Member functions are stored in code segment.
*/