
/*
- It is not compulsory to have data members in C++ structures.
- It is compulsory in C structures.
- When a C++ struct is written without data members,
  the object takes up one byte of memory.
- Its purpose is to indicate the presence of an object.
*/