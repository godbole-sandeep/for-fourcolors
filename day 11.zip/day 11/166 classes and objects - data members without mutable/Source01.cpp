#include <iostream>

#include "Circle.h"

int main() {
	Circle a(5);
	std::cout << a.GetArea() << std::endl;
	std::cout << a.GetArea() << std::endl;
	std::cout << a.GetArea() << std::endl;

	a.SetRadius(10);
	std::cout << a.GetArea() << std::endl;
	std::cout << a.GetArea() << std::endl;
	std::cout << a.GetArea() << std::endl;

	return 0;
}

/*
What is the key point to note in the program above?
- Const member functions prevent changes to an object's data members.
- 'Circle::GetArea' prevents changes to the data member 'm_area'.
*/