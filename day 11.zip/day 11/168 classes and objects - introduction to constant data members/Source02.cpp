class Math {
public:
	Math() {
		m_pi = 3.14;
	}
public:
	double PI() {
		return m_pi;
	}
private:
	const double m_pi;
};

int main() {
	Math m;
	double pi = m.PI();
	return 0;
}

/*
What are the key points to note in the program above?
- Const data members cannot be initialized in the constructor body,
  because it is treated as assignment and not initialization.
- Assignment to a constant data member is not possible.
*/