class Math {
public:
	Math() {}
public:
	double PI() {
		return m_pi;
	}
private:
	const double m_pi;
};

int main() {
	Math m;
	double pi = m.PI();
	return 0;
}

/*
What is the key point to note in the program above?
- Initialization of a const data member is required.
*/