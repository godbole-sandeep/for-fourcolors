
/*
- Another option to resolve conflict is by prefixing member with 'class-name::'.
*/