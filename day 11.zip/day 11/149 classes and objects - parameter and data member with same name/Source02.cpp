
/*
- The 'this' pointer helps resolve conflicts between parameters and data members
  having same names.
*/