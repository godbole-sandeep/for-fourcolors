
/*
- The 3rd method to resolve conflict is to use some prefix for data members.
- In the above example we have used 'm_' as a prefix.
- 'm_' implies member.
- Note that writing 'm_' is not compulsory.
- An organization may choose to write different prefix in place of 'm_'.
*/