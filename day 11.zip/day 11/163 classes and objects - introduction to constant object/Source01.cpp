#include "Circle.h"

int main() {
	const Circle a(5);
	int r = a.GetRadius();
	a.Print();
	double area = a.GetArea();
	return 0;
}

/*
Why does the program fail to compile?
- Since 'a' is 'const', the compiler expects that any member functions called on it won't modify its state.
- Since 'GetRadius', 'Print', and 'GetArea' do not adhere to this assumption,
  the compiler generates an error.
*/