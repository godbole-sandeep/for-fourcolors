
/*
- 'Print' and 'main' both are global functions.
- We did not see any additional pointers in 'Print' except pobj.
*/