
/*
- C++ implements the 'this' pointer as constant pointer (Circle * const this).
- Therefore assigning the address of another object to the 'this' pointer causes a compilation error.
*/