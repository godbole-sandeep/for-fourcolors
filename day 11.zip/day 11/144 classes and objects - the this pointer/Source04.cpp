
/*
- Since 'this' and 'pobj' point to the same object,
  'pobj' can be substituted with 'this'.
*/