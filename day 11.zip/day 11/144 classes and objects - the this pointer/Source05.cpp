
/*
- Since 'pobj' is no longer needed, it can be fully eliminated from
  the 'Print' function.
*/