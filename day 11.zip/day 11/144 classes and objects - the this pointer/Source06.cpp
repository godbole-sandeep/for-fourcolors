
/*
- The 'this' pointer is always present implicitly when a member is accessed.
- Except for resolving the name conflict (which will be discussed�later),
  explicitly specifying the 'this' pointer�is not essential.
*/