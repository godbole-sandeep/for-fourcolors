
/*
- In C++, function can be a member of structure.
- This type of function is known as a "member function".
- Upon stepping into the Print, two identifiers were noted the 'this' and the 'pobj'.
- Both were noticed to contain same address.
- When a function is made a member function, C++ introduces the 'this'
  pointer implicitly within it.
- It is only seen in non-static member functions and not in static or global functions.
- Note it dosn't exist in struct.
- The 'this' is a keyword in C++.
- It is automatically assigned the address of an object on which
  the member function is invoked.
- Logically speaking, the 'this' pointer can be considered as the first parameter of
  a non-static member function.
*/

