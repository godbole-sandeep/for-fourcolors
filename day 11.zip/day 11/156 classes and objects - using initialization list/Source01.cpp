class Integer {
public:
	Integer(int i) {}
private:
	int m_i;
};

int main() {
	Integer a(5);
	return 0;
}

/*
What is the key point to note in the program above?
- The data member(s) can also be initialized using an initialization list.
- If there are multiple data members, use commas to separate the initialization expressions for each one.
*/