
/*
- The data member(s) can also be initialized using initialization list.
- If there are multiple data members then use commas to separate the
  initialization expression for each one.
*/