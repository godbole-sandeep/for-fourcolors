
/*
- If C++ struct is allowed to have one member function, then
  we can have as many as we want.
- A member function that returns value of a data member is called a getter or accessor.
- A member function that allows modification to the data member is
  called a setter or mutator.
- Setter may validate arguments before assigning them to respective data members.
  Note that in the above program, 'SetRadius' validates 'radius' before
  assigning it to the 'm_radius'.
*/