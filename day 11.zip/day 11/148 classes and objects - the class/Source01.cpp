
/*
- What is a class?
  A class in C++ is a blueprint that specifies an object's structure and behavior.
- By default, struct members have public access.
- By default, class members have private access.
- The default access of struct or class can be overriden with suitable access specifiers.
- Instances of a class have the same features as the class they are based on.
*/