#include <iostream>

#include "Circle.h"

int main() {
	Circle a(5);
	std::cout << a.GetArea() << std::endl;
	std::cout << a.GetArea() << std::endl;
	std::cout << a.GetArea() << std::endl;

	a.SetRadius(10);
	std::cout << a.GetArea() << std::endl;
	std::cout << a.GetArea() << std::endl;
	std::cout << a.GetArea() << std::endl;

	return 0;
}

/*
What are the key points to note in the program above?
- Note the 'mutable' keyword on the 'm_area' data member.
- The 'mutable' keyword applies to a data member.
- A mutable data member can be modified within a const member function.
- There are two types of constness: bitwise constness and logical constness.
- Bitwise constness occurs when even a single bit of the object cannot be modified.
- Logical constness occurs when some parts of the object can be modified while the rest remains constant.
- The 'mutable' keyword enables logical constness.
*/