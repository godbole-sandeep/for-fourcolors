int g_data;

class MyClass {
public:
	MyClass();
public:
	void F() const;
private:
	int m_data;
};

MyClass::MyClass() {
	m_data = 0;
}

void MyClass::F() const {
	int data = 0;
	data = 1;
	g_data = 1;
	m_data = 1;
}

int main() {
	const MyClass a;
	a.F();
	return 0;
}

/*
What are the key points to note in the program above?
- Local and global variables can be modified within a 'const' function.
- However, data members cannot be modified within a 'const' function.
*/
