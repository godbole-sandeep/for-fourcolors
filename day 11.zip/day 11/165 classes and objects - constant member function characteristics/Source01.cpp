class MyClass {
public:
	void F();
	void G() const;
};

void MyClass::F() {}

void MyClass::G() const {}

int main() {
	MyClass a;
	a.F();
	a.G();

	const MyClass b;
	b.F();
	b.G();

	return 0;
}

/*
What are the key points to note in the program above?
- A const member function can be called on both const and non-const objects.
- A non-const function can be called only on non-const objects.
- Thus, const member functions are versatile than non-const member functions.
- Therefore, whenever possible, attempt to declare member functions as const.
- If the purpose of the member function is to alter the state of the object,
  then it cannot be specified as a const member function.
*/