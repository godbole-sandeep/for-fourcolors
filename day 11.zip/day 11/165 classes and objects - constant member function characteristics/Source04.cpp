class MyClass {
public:
	void F();
	void G() const;
public:
	void H();
	void K() const;
};

void MyClass::F() {}

void MyClass::G() const {}

void MyClass::H() {
	F();
	G();
}

void MyClass::K() const {
	F();
	G();
}

int main(){
	return 0;
}

/*
What are the key points to note in the program above?
- A non-const member function can call both const and non-const member functions.
- A const member function can only call other const member functions.
*/
