class MyClass {
public:
	void F();
	void F() const;
};

void MyClass::F() {}

void MyClass::F() const {}

int main() {
	MyClass a;
	a.F(); // Step into here to check which 'F' is getting called?

	const MyClass b;
	b.F(); // Step into here to check which 'F' is getting called?

	return 0;
}

/*
What is the key point to note in the program above?
- Function overloading is possible between const and non-const non-static member functions.
*/