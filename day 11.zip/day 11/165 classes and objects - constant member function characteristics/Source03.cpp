class MyClass {
public:
	void F() const;
	static void G() const;
};

void MyClass::F() const {}

void MyClass::G() const {}

int main() const {
	MyClass a;
	a.F();
	a.G();
	return 0;
}

/*
What are the key points to note in the program above?
- Global and static member functions cannot be declared as 'const' functions,
  as they lack the 'this' pointer.
- Only non-static member functions can be specified as 'const' member functions.
*/
