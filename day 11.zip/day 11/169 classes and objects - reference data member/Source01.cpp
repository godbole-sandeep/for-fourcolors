#include <iostream>

class MyClass {
private:
    int& m_ref;
public:
    MyClass(int& r) : m_ref(r) {}

    void SetRefValue(int value) {
        m_ref = value;
    }

    int GetRefValue() const {
        return m_ref;
    }
};

int main() {
    int value = 5;
    MyClass obj(value);

    std::cout << "Initial value of reference: " << obj.GetRefValue() << std::endl;

    obj.SetRefValue(10);
    std::cout << "Updated value of reference: " << obj.GetRefValue() << std::endl;

    return 0;
}

/*
What is the key point to note in the program above?
- Reference data members must be initialized in the initialization list.
*/