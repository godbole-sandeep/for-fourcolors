#include <assert.h>
#include <iostream>
#include <stdexcept>

class Circle {
private:
	int m_radius;
public:
	Circle() { // default constructor
		m_radius = 1;
	}

	Circle(int radius) { // parametric constructor
		SetRadius(radius);
	}
public:
	int GetRadius() {
		assert(m_radius > 0);
		return m_radius;
	}

	void SetRadius(int radius) {
		if (radius <= 0)
			throw std::invalid_argument("Radius must be positive number.");
		m_radius = radius;
	}
public:
	void Print() {
		assert(m_radius > 0);
		std::cout << m_radius << std::endl;
	}
};

int main() {
	Circle a; // calls default constructor
	a.Print();

	Circle b(5); // calls parametric constructor
	b.Print();

	return 0;
}

/*
Is it possible to overload constructors?
- Yes, it is possible to overload constructors.
*/