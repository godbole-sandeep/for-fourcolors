
/*
- Overloading of constructors is possible.
*/