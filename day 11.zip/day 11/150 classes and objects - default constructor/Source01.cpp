#include <assert.h>
#include <iostream>
#include <stdexcept>

class Circle {
private:
	int m_radius;
public:
	int GetRadius() {
		assert(m_radius > 0);
		return m_radius;
	}

	void SetRadius(int radius) {
		if (radius <= 0)
			throw std::invalid_argument("Radius must be a positive number.");
		m_radius = radius;
	}
public:
	void Print() {
		assert(m_radius > 0);
		std::cout << m_radius << std::endl;
	}
};

int main() {
	Circle a;

	a.SetRadius(5); // Sets radius to 5

	int r = a.GetRadius(); // Retrieves the radius

	a.SetRadius(10); // Sets radius to 10

	return 0;
}
/*
- A constructor is a special member function of a class.
- It is called automatically whenever an object is defined.
- The constructor must have the same name as the class.
- No return type is to be specified for the constructor.
- Specifying a return type on the constructor causes a compilation error.
- A default constructor is provided by the compiler when a class is written
  without any constructor. This constructor doesn't do anything. A compiler
  cannot provide a default constructor if a constructor of any kind�such as
  default, parametric, or copy�is written in the class.
- Constructor provides an opportunity to initialize the object's data members.
- If no initialization code is written in the constructor, the object's
  data members will remain uninitialized.
*/