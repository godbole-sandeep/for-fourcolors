
/*
- A constructor is a special member function of a class.
- It is called automatically whenever an object is defined.
- The constructor must have the same name as the class.
- No return type is to be specified for the constructor.
- Specifying a return type on the constructor causes a compilation error.
- A default constructor is provided by the compiler when a class is written
  without any constructor. This constructor doesn't do anything. A compiler
  cannot provide a default constructor if a constructor of any kind�such as
  default, parametric, or copy�is written in the class.
- Constructor provides an opportunity to initialize the object's data members.
- If no initialization code is written in the constructor, the object's
  data members will remain uninitialized.
*/