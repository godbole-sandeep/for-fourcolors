
/*
What is the key point to note in the program above?
- The 'GetVarAddress' function is returning the address of the global variable 'var'.
*/