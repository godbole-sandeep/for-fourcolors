
/*
What is the key point to note in the program above?
- The 'var' is now a local variable of 'GetVarAddress'.
- The 'GetVarAddress' function is returning the address of a local variable.
- Since local variables are released once control exits the function,
  it is not advisable to return the address of such released variables.
- It creates a dangling pointer when it receives the address of a released variable.
- Therefore, it is not advisable to return the address of a local, non-static variable.

What is dangling pointer?
- A dangling pointer is a pointer that continues to point a memory location that
  has been deallocated or released.
*/