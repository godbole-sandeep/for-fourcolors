
/*
What are the key points to note in the program above?
- It is okay to pass a null pointer to the delete operator.
- It is okay to pass a valid pointer to the delete operator.
- It is not okay to pass a dangling pointer to the delete operator.
*/