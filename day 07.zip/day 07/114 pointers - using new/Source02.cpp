
/*
What is the key point to note in the program above?
- Note the argument passed after the type in the 'new' expression.
- It is used to initialize the memory block allocated by 'new'.
*/