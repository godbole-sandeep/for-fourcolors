
/*
What are the key points to note in the program above?
- Note the usage of the 'new' and 'delete' operators in the program.

What does the 'new' operator do?
- The 'new' operator allocates a block of memory of the specified type
  and size from the freestore.
- If the new operator is followed by an initialization expression,
  it initializes the allocated memory with the given value.
- The new operator returns a pointer to the allocated memory.
- If the allocation fails (e.g., if there is not enough memory available),
  the new operator throws a std::bad_alloc exception.
- Allocation done using 'new' must be freed using the 'delete' operator.
- It's a good practice to assign 'nullptr' to the freed pointer.

What are the differences between 'malloc' and 'new', and between 'free' and 'delete'?
- 'new' and 'delete' are operators, whereas 'malloc' and 'free' are functions.
  Therefore, to work with 'malloc' and 'free', the header file 'malloc.h' needs to be included.
  For 'new' and 'delete', no header file needs to be included.
- With 'new', the compiler automatically determines the number of bytes to be reserved;
  with 'malloc', the number of bytes to reserve must be explicitly passed.
- No type casting is needed for the value returned by 'new', but explicit type casting
  is required for the return value of 'malloc'.
- Memory reserved using 'new' should be freed using the 'delete' operator,
  while memory reserved using 'malloc' should be freed using the 'free' function.
- 'new' and 'delete' can only be used in C++ programs, whereas 'malloc' and 'free' can
  be used in both C and C++ programs.
- 'new' invokes constructors, whereas 'malloc' does not.
- 'delete' invokes destructors, but 'free' does not.
- If 'new' fails, it throws a std::bad_alloc exception.
  If 'malloc' fails, it returns NULL.
*/