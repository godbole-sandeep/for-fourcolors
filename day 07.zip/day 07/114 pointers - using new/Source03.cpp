
/*
What are the key points to note in the program above?
- 'new' is used to allocate an array of integers.
- Also note the use of 'delete[]' instead of just 'delete'.

What precaution should be taken while working with delete?
- Use the same form of new and delete.
- If new[] is used, then use delete[].
- If new is used without [], then do not use [] with delete.
*/