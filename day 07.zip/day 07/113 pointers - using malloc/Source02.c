
/*
What is the key point to note in the program above?
- 'malloc' is used to allocate an array of integers.

What is an array allocated using 'malloc' known as?
- An array allocated using 'malloc' is known as a dynamic array.
- The size of a dynamic array can be changed at runtime by reallocating
  the array with a different size.

What are arrays like 'int arr[5]' known as, and can their size be modified at runtime?
- The arrays such as int arr[5], are known as fixed-size arrays.
- The size of such arrays cannot be modified at runtime.

How can you view elements of a dynamic array in the Watch window?
- To see the contents of all elements in the Watch window,
  write an expression such as 'array-name, size'.
- By default, both the Locals and Watch windows show the contents of
  the first element only.
*/