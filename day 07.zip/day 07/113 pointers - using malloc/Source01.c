
/*
What are the key points to note in the program above?
- Note the usage of the 'malloc' and 'free' functions in the program.

What does the 'malloc' function do?
- The malloc function allocates a specified amount of memory from the heap
  and returns a pointer to the beginning of the allocated memory block.
- The allocated memory is uninitialized, meaning it contains whatever data
  was already in that memory location.
- If the allocation fails, malloc returns a NULL.
- Allocation done using 'malloc' must be freed using the 'free' function.
- It's a good practice to assign 'NULL' to the freed pointer.

Does 'malloc' allocate a contiguous block of memory?
- Yes, 'malloc' allocates a contiguous block of memory.
- This means the memory it allocates is a single, continuous sequence of
  bytes in the memory address space.
- However, blocks allocated by two 'malloc' calls may not be contiguous.
- If 'malloc' fails to find a contiguous block, it returns NULL.
*/
