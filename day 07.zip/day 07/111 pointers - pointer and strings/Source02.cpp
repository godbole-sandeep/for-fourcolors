
/*
What is the key point to note in the program above?
- Observe the addresses stored in 'pstr' and 'pstr2'.
- They are the same.
- This illustrates that both 'pstr' and 'pstr2' are pointing to the
  same string literal "Hello, World" stored in constant memory.
- Also, note the usage of 'const' on the pointer.
- Pointers will point to 'the same string' if the 'string is the same'.

How is this different from the previous program?
- In the previous program, 'str' contained a copy of the string literal "Hello, World".
- In the present program, 'pstr' and 'pstr2' are directly pointing to the string literal
  "Hello, World" stored in constant memory.
- No copy is created.

Can a string stored in constant memory be modifed?
- Constant memory is read-only.
- Therefore, anything stored in constant memory cannot be modified.
- String literals are also called immutable (non-modifiable) strings.
*/
