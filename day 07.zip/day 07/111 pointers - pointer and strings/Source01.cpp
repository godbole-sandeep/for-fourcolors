
/*
What are the key points to note in the program above?
- A string literal, such as "Hello, World", is stored in constant memory.
- By default, a string literal is terminated with a null character.

What happens when the statement 'char str[] = "Hello, World";' is executed?
- A copy of the string literal "Hello, World" is stored in an array.
- Thus, there exist two "Hello, World" strings in the process: one in the
  constant memory and the other in the array 'str', which is in the stack
  memory.
- The string stored in constant memory cannot be modified.
- However, the string stored in 'str' can be modified.
*/