
/*
What are the key points to note in the program above?
- The program first allocates memory on the freestore.
- It then immediately releases it.
- This prevents any memory leakage.

What is '_CrtDumpMemoryLeaks'?
- '_CrtDumpMemoryLeaks' is a function in the C runtime library used for
  detecting memory leaks in a program.
- Include 'crtdbg.h' to use the function.
*/