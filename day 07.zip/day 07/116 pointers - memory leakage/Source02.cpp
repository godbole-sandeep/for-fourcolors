
/*
What are the key points to note in the program above?
- The program allocates memory on the heap for an integer, assigns it a value of 1,
  and then sets the pointer to nullptr without freeing the allocated memory,
  causing a memory leak.
- It then allocates memory for another integer, assigns it a value of 2,
  properly deletes the allocated memory, and sets the pointer to nullptr.
- Finally, _CrtDumpMemoryLeaks is called, which detects the memory leak
  from the first allocation that was not freed.
- As a result, the program will report a memory leak for the first integer allocation.
*/