
/*
What is the key point to note in the program above?
- Memory allocated on the freestore may not be immediately released in the same function.
- An API developer may write two functions, one for allocation and another for release.
- In such cases, memory allocated by the create function may not be immediately released.
*/