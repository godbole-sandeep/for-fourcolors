
/*
What is the key point to note in the program above?
- Note the type of 'arr' in the Locals window.
*/