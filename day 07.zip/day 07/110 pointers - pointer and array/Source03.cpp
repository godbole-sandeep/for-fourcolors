
/*
What is the key point to note in the program above?
- Note the change made to the signature of the 'Print' function.
*/