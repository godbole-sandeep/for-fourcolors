
/*
What are the key points to note in the program above?
- The dereferencing operator and array operator can be used with both pointers and arrays.
*/