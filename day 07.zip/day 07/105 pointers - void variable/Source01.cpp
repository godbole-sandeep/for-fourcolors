
/*
What is the key point to note in the program above?
- A variable of void type cannot be created.
*/