
/*
What does '()' after a function name, for example, 'Print()', signify?
- The '()' after the function name indicates that you want to call that function.

Does a function have an address?
- Yes, functions do have addresses.

How do you obtain the address of a function?
- To obtain the address of a function:
  1. Precede the function name with the address-of operator (&). And
  2. Do not write '()' next to the function name.
  For example, if 'Add' is a function, write '&Add' to obtain the address
  of the 'Add' function.
- Alternatively, you can also write just the name of the function without ().
  This expression also returns the address of the function.
  For example, writing just 'Add' also returns the address of the 'Add' function.

What is 'operation' defined in main function?
- It is known as a function pointer.
- It has the ability to store the address of a function.
- It can store the address of only those functions that match its signature.
- For example, it can store the address of only those functions that accept
  two int parameters and return an int.
- The address of a function that does not conform to this signature cannot be
  stored in the 'operation' function pointer.
*/