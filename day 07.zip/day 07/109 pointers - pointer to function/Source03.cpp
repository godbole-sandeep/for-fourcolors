
/*
What is the key point to note in the program above?
- The program demonstrates practical use of a function pointer.
*/