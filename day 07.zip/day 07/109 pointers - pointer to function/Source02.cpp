
/*
Why code fails to compile?
- The code fails to compile because the function 'SayHello' does not
  match the signature of the function pointer 'operation'.
- As a result, the program fails to compile.
*/