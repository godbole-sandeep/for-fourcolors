
/*
What does '*' in 'int* pi' indicate?
- The '*' in 'int* pi' signifies that 'pi' is a special variable intended to store
  an address rather than a data value.
- It should not be confused with the dereferencing operator.
- This star '*' is not a dereferencing operator but rather a component of the pointer
  declaration syntax.

What does the 'int' in 'int* pi' indicate?
- The 'int' in 'int* pi' indicates that the pointer 'pi' is pointing to a memory
  location where an integer is stored.

Why can we assign the address of 'i' to 'pi'?
- The expression '&i' returns the address where the integer variable 'i' is located.
- Since 'pi' is a pointer to an integer, it is designed to store addresses of locations
  where integers are stored. 
- Therefore, assigning the address of 'i' to 'pi' is valid and aligns with the
  expectations of a pointer to an integer.

Why can we assign the address of 'd' to 'pd'?
- The expression '&d' returns the address where the double variable 'd' is located.
- Since 'pi' is a pointer to a double, it is designed to store addresses of locations
  where doubles are stored.
- Therefore, assigning the address of 'd' to 'pd' is valid and aligns with the
  expectations of a pointer to a double.

Why can't we assign the address of 'd' to 'pi'?
- The expression '&d' returns the address where the double variable 'd' is located.
- Since 'pi' is a pointer to an integer, it is designed to store addresses of locations
  where integers are stored.
- Therefore, assigning the address of 'd' to 'pi' does not align with the expectations
  of a pointer to an integer.
- This mismatch leads to an error.
*/