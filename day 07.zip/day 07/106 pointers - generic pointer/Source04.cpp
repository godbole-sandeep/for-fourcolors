
/*
What is the key point to note in the program above?
- To dereference a generic pointer, it must first be cast to a specific pointer
  type that corresponds to the type of data it points to.
*/
