
/*
What is generic pointer?
- A generic pointer, also known as a void pointer, is a special type of
  pointer that can point to any data type.
- It is defined as 'void*'.
- Conversion from a specific pointer type to a generic pointer (void*) happens implicitly,
  but conversion from a generic pointer to a specific pointer type requires an explicit cast.
*/
 