
/*
What is the key point to note in the program above?
- Generic pointers, or void* pointers, cannot be dereferenced directly because
  they do not have a specific data type associated with them.
- To dereference a generic pointer, it must first be cast to a specific pointer
  type that corresponds to the type of data it points to.
*/