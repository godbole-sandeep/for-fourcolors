
/*
What is the key point to note in the program above?
- The arguments are passed to the 'Swap' function by address rather than by value.
- Passing arguments by address to the 'Swap' function results in the swapping of
  their values because the function operates directly on the memory locations of
  the variables, rather than working with copies of the values.
*/