#include <iostream>

int main() {
	int a = 1;
	int* pa = &a;

	std::cout << "a = " << a << std::endl;
	std::cout << "pa = " << pa << std::endl;
	std::cout << "*pa = " << *pa << std::endl;

	a = 2; // direct access
	std::cout << "a = " << a << std::endl;
	std::cout << "pa = " << pa << std::endl;
	std::cout << "*pa = " << *pa << std::endl;

	*pa = 5; // indirect access
	std::cout << "a = " << a << std::endl;
	std::cout << "pa = " << pa << std::endl;
	std::cout << "*pa = " << *pa << std::endl;

	return 0;
}

/*
What does it mean to dereference a pointer?
- Dereferencing a pointer means accessing the value stored at
  the memory location that the pointer is pointing to.
- When you have a pointer that holds the address of a variable,
  dereferencing allows you to read or modify the value of that
  variable through the pointer.

How to dereference a pointer?
- Dereferencing is done using the '*' operator.
- For example, if you have a pointer 'pa' that points to an integer
  variable 'a', you can access the value of 'a' through '*ptr'. 
*/