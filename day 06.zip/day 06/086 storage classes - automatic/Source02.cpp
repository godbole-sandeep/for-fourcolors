int main() {
	return 0;
}

void f() {
}


/*
Can two or more functions have local variables with the same name?
- Yes, two or more functions can have local variables with the same name.
- Each function's local variables are scoped to that function, so they
  do not interfere with each other.
*/
