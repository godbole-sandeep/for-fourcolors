#include <iostream>

void Update();

int main() {
	Update();
	Update();
	Update();
	return 0;
}

void Update() {
	int i = 1;
	std::cout << i << std::endl;
	i = i + 1;
}


/*
Why does the program output '1 1 1' instead of '1 2 3'?
- The program outputs 1 1 1 because each time the 'Update' function is called,
  it declares a new local variable 'i' and initializes it to 1.
- The value of 'i' is then printed, showing 1 each time.
- After printing, the variable 'i' is incremented by 1, but this change is not
  retained for the next call to Update because 'i' is released everytime
  'Update' call is exited.
- Therefore, every call to 'Update' starts with 'i' being set to 1,
  resulting in the output 1 1 1. 
*/
