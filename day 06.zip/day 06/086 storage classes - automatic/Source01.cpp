int main() {
	return 0;
}

void Update() {
}

/*
What is a local variable?
- A local variable is a variable defined within a block of code,
  such as within a function, loop, or conditional statement, and
  is only accessible within that block.
- For example, 'i' is a local variable of the 'main' function.
- The scope of 'i' is limited to the 'main' function.
- 'i' is also a non-static local variable of the 'main' function.
- Non-static local variables are also called automatic variables.

What is the scope of a local variable?
- The scope of a local variable is limited to its block.

What is the lifetime of a local variable?
- The lifetime of a local variable is limited to its block.
- It begins at the start of the block and ends as soon as control exits the block.

Where are local variables located in memory?
- Local variables exist in the statck frame.

Why does the compiler fail to compile the code?
- The scope of local variable is limited to the block in which it is defined.
- Because 'i' is a local variable of 'main', its scope is restricted to the 'main'.
- It cannot be used in any other function.
*/