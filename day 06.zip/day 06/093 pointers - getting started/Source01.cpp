#include <iostream>

int main() {
	int a = 1;
	int b = 2;
	int temp = 0;

	std::cout << "Before swap:" << std::endl;
	std::cout << "a = " << a << ", b = " << b << std::endl;

	temp = a;
	a = b;
	b = temp;

	std::cout << "After swap:" << std::endl;
	std::cout << "a = " << a << ", b = " << b << std::endl;

	return 0;
}

/*
What is the above program doing?
- It is swapping the values of 'a' and 'b'.
- Watch the values of 'a' and 'b' in the Locals window.
- Lines 6, 7, and 8 perform the swapping, and these steps
  form what is known as the swapping algorithm.

What is next?
- The code is working fine and it is swapping values of 'a' and 'b' between them.
- Now, I want to write a 'Swap' function and move the swapping algorithm to that
  function so that I can use the same algorithm with other variables.
- The next source file, 'Source02.cpp', is trying to do the same.
*/