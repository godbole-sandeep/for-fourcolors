#include <iostream>

void Swap(int u, int v);

int main() {
	int a = 1;
	int b = 2;

	std::cout << "Before swap:" << std::endl;
	std::cout << "a = " << a << ", b = " << b << std::endl;

	Swap(a, b);

	std::cout << "After swap:" << std::endl;
	std::cout << "a = " << a << ", b = " << b << std::endl;

	return 0;
}

void Swap(int u, int v) {
	int temp = u;
	u = v;
	v = temp;
}

/*
What is the observation?
- When the swapping algorithm was part of the 'main' function in the previous program,
  the values of 'a' and 'b' were getting swapped.
- Now that the algorithm is placed in the 'Swap' function, the values of 'a' and 'b'
  are not swapped.

Why did the 'Swap' function fail to swap the values of 'a' and 'b'?
- The Swap function failed to swap the values of a and b because it
  used pass-by-value for its parameters.
- This means the function worked with copies of a and b rather than
  the original variables.
- Consequently, any changes made to the parameters u and v within
  the Swap function did not affect the original a and b in the
  main function.

So what is the solution to this problem?
- The solution is to pass the parameters to the function by address.

Then, what is an address?
- To understand what an address is, we need to delve a bit deeper
  into computer architecture. 
- A computer consists of several key components, such as the CPU,
  memory, storage, motherboard, power supply, and input/output devices.
- The concept of an address is specifically related to memory.
- Hence we will put more focus on the memory.

What is memory?
- Memory is a component of a computer system that provides temporary
  storage for data and instructions.
- It is organized into a series of locations, where data is stored and
  retrieved.
- Each location is identified by a unique number known as 'address'.
- Thus, an address is essentially a unique number that identifies a
  specific memory location.

What are variables?
- Variables can be thought of as boxes or containers in which data is stored.

Where are variables manifested?
- Variables are manifested in memory.

If each memory location is identified by an address and variables are manifested
in memory, then is the concept of an address applicable to variables?
- Yes, the concept of an address is applicable to variables as well.
- Thus, a variable is identified by its address in memory.

Then how do I obtain the address of a variable?
- The next program demonstrates how to obtain the address of a variable.

*/