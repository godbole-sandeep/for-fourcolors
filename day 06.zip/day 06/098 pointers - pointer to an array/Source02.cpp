#include <iostream>

int main() {
	int a[] = { 1, 2, 3 };
	std::cout << a << std::endl;

	int* pa = a; // a pointer can point to an array
	std::cout << pa << std::endl;

	return 0;
}

/*
What is the key point to note in the program above?
- Since the array name without a subscript returns the base address of the array,
  a pointer variable can be used to store this address.
- In this case, the pointer is said to point to the array.
*/