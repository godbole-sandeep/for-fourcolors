#include <iostream>

int main() {
	int a[] = { 1, 2, 3 };
	std::cout << a << std::endl;
	return 0;
}

/*
What is the key point to note in the program above?
- When the array name is referred to without a subscript,
  it returns the base address of the array.
*/
