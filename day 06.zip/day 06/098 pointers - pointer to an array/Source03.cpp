#include <iostream>

int main() {
	int i = 1, j = 1;
	int a[2][3] = { { 1, 2, 3 }, { 4, 5, 6 } };

	std::cout << a << std::endl;
	std::cout << "&a[i] = " << &a[i] << ", a + i = " << a + i << std::endl;
	std::cout << "&a[i][0] = " << &a[i][0] << ", *(a + i) = " << *(a + i) << std::endl;
	std::cout << "&a[i][j] = " << &a[i][j] << ", *(a + i) + j = " << *(a + i) + j << std::endl;
	std::cout << "a[i][j] = " << a[i][j] << ", *(*(a + i) + j) = " << *(*(a + i) + j) << std::endl;

	return 0;
}

/*
What are the key points to note in the program above?
- The expression 'a' provides the base address of the two-dimensional array.
- The expression 'a + i' gives the base address of the 'i'th row.
- The expression '*(a + i)' gives the base address of the element identified
  by the ith row and 0th column.
- The expression '*(a + i) + j' gives the base address of the element identified
  by the ith row and jth column.
- The expression '*(*(a + i) + j)' provides the value of the element identified
  by the ith row and jth column.

What is the take away from the above program?  
- Avoid using pointer arithmetic as it can be very complex.
- Instead, use pointers with array operators for simplicity and clarity.
*/

