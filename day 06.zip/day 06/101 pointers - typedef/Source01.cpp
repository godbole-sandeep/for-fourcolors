int main() {
	int* p, q;
	typedef  int* int_ptr;
	int_ptr r, s;
	return 0;
}

/*
What is typedef?
- 'typedef' is a keyword used to create an alias for an existing data type.

What are the key points to note in the program above?
- The declaration 'int* p, q' defines 'p' as a pointer to 'int' and 'q' as
  an 'int', not a pointer to 'int'.
- 'int_ptr' is a type alias for 'int*'.
- When the 'int_ptr' type alias is used, both 'r' and 's' are defined as pointers.
*/
