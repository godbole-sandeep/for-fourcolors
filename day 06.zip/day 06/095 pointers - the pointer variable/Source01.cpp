void main() {
	int* pa;
	return 0;
}

/*
What is 'pa' in the above program?
- It is a special variable known as pointer variable.
- The purpose of the pointer variable is to store address.
- It never stores data value.
- Instead, it always stores address.

What is wild pointer?
- A wild pointer is a pointer that has not been initialized.
- In the above program, 'pa' is a wild pointer.

Are pointers and addresses the same?
- No, they are not the same.
- An address is the value that identifies a specific memory location.
- A pointer, on the other hand, is a variable that stores this address.
*/
