#include <iostream>

int var = 5;

int main() {
	int var = 1;
	std::cout << var << std::endl;
	return 0;
}

/*
What is the key point to note in the program above?
- The program defines two variables: one as a global variable and
  the other as a local variable.
- The variables have the same name: 'var'.

Which 'var' will 'std::cout << var << std::endl;' access?"
- When a local and a global variable have the same name, the local variable
  always takes precedence over the global one.
- Therefore, 'std::cout << var << std::endl;' accesses local 'var'.

How can I access the global 'var' when a local 'var' is present?
- Use the scope resolution operator.
- The next source file demonstrates the use of the scope resolution operator.
*/