#include <iostream>

int var = 5;

int main() {
	int var = 1;
	std::cout << var << std::endl;
	return 0;
}

/*
How can I access a global variable when a local variable with the same name is present?
- When a local variable hides a global variable with the same name, you can use the
  scope resolution operator to access the global variable.
*/