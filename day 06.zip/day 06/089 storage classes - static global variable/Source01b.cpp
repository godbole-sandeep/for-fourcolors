#include "globals.h"

void AssignFifteen() {
	var = 15; // Accessing and modifying global variable
}

void AssignTwenty() {
	var = 20; // Accessing and modifying global variable
}