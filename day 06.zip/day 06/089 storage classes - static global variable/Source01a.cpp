#include <iostream>

#include "globals.h"

int main() {
	var = 5; // Accessing and modifying global variable
	AssignTen();
	AssignFifteen();
	AssignTwenty();
	return 0;
}

void AssignTen() {
	var = 10; // Accessing and modifying global variable
}

/*
What is a static global variable?
- A static global variable is a global variable that is limited in scope
  to the file in which it is defined.
- The scope of a static global variable is restricted to the file in which it is defined.
- This means that it cannot be accessed from other files, even if those files include
  the header file where the variable is declared.
- Despite their restricted scope, static global variables have a lifetime that lasts
  for the entire duration of the application.
- They are initialized only once and retain their value for the entire run of the application.
- For example 'var' is a static global variable.
- Static global variables are located in the data segment of memory.

What happens when a static global variable from one source file is accessed in another?
- It results in a linking error.

Is it valid to define static global variables with the same name in multiple source files?
- Yes.

What is Data Segment?
- A data segment is part of the process's memory layout where global and static variables
  that are explicitly initialized are stored.
- It is divided into: Initialized Data Segment and Uninitialized Data Segment (BSS)
- Initialized Data Segment: Stores variables that are explicitly initialized by the programmer.
- Uninitialized Data Segment (BSS): Stores variables that are declared but not explicitly initialized;
  these are automatically set to zero.
*/
