#pragma once

// Global variable declaration
extern int var; 

// Function prototypes
void AssignTen();
void AssignFifteen();
void AssignTwenty();