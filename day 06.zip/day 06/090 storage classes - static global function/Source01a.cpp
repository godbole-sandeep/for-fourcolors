#include "globals.h"

int main() {
	SayHello();
}

/*
What is static function?
- A static function is a function that is limited in scope to the file in which it is defined.
- This means it cannot be called or accessed from other files, even if they include the file
  where the function is declared.
- While a regular function has external linkage, a static function has internal linkage.
- It is often used to implement helper function that are intended for use only within a specific file.

What is linkage?
- Linkage determines the visibility of a function or variable outside its translation unit
  or restricts it to within the translation unit.
- External Linkage: Makes the function or variable accessible from other translation units.
- For example non-static global variables and functions have external linkage.
- Internal Linkage: Limits the visibility of the function or variable to the translation unit
  in which it is defined.
- For example, static global variables and functions have internal linkage.

What is a translation unit?
- A preprocessed source file, including all headers, is called a translation unit.
*/
