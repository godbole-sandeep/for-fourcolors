#pragma once

// Function prototypes
void SayHello();