#include <iostream>

void CountCalls();

int main() {
	CountCalls();
	CountCalls();
	CountCalls();
	return 0;
}

void CountCalls() {
}

/*
What is static local variable?
- A static local variable is a variable that retains its value between function calls.
- Unlike regular local variables, which are reinitialized each time the function is called,
  static local variables preserve their value for the lifetime of the program.
- Example, variable 'callCount' of 'CountCalls' function.
- The lifetime of static variable is for the entire duration of the application.
- It is initialized only once and retains its value across function calls.
- The variable is only accessible within the function where it is defined because
  it is a local variable.
- Static local variable is also stored in the data segment of memory.
- Note that lifetime and scope are distinct properties.
- Just because a variable has a lifetime for the entire application does
  not mean it has scope for the entire application.
*/