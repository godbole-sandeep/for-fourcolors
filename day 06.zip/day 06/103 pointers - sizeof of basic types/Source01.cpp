#include <iostream>

int main() {
	std::cout << sizeof(int) << std::endl;
	std::cout << sizeof(char) << std::endl;
	std::cout << sizeof(wchar_t) << std::endl;
	std::cout << sizeof(float) << std::endl;
	std::cout << sizeof(double) << std::endl;
	std::cout << sizeof(bool) << std::endl;
	return 0;
}

/*
What are the sizes of primary types in 32 bit and 64 bit applications?
- The sizes of primary types are the same in both 32-bit and 64-bit applications.
- The sizes of each primary type are as follows: 'int' is 4 bytes, 'char' is 1 byte,
  'wchar_t' is 2 bytes, 'float' is 4 bytes, 'double' is 8 bytes, and 'bool' is 1 byte.
*/
