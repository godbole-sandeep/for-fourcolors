#include <iostream>

int main() {
	int a = 1;
	std::cout << a << std::endl;
	std::cout << &a << std::endl;
	return 0;
}

/*
What is the key point to note in the program above?
- Pay attention to the usage of the '&' operator before the variable 'a' in line 6.
- The '&' operator is known as 'address of' operator.
- When applied to a variable, it returns the address of that variable.
*/