int main() {
	int a = 1;
	int* pa = &a; // pointer initialization
	return 0;
}

/*
What is the key point to note in the program above?
- The pointer 'pa' is initialized with the address of the variable 'a'.

How do you draw a pointer?
- Draw two boxes: One for the pointer and other for the location pointer points to.
- Draw an arrow from the pointer box to location box.

     +-----+        +-----+
  pa | 100 | -----> |  1  | a
     +-----+        +-----+
	                  100
*/