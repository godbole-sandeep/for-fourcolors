int main() {
	int a = 1;
	int* pa = nullptr;
	pa = &a; // pointer assignment
	return 0;
}

/*
What are the key points to note in the program above?
- The pointer 'pa' is initialized with 'nullptr' instead of
  the address of a particular variable.
- The pointer is then assigned the address of the variable 'a'.

What is 'nullptr'?
- 'nullptr' is a keyword in C++ that represents a null pointer constant.
- It is used to indicate that a pointer does not point to any object
  or valid memory location.
- Thus, when we don't want the pointer to point to a specific variable or
  location, we prefer to initialize or assign `nullptr` to the pointer.
- The type of 'nullptr' is std::nullptr_t.
- A pointer stored with 'nullptr' is known as a 'null pointer'.
*/