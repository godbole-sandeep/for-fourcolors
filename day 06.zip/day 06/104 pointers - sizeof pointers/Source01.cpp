#include <iostream>

int main() {
	std::cout << sizeof(int*) << std::endl;
	std::cout << sizeof(char*) << std::endl;
	std::cout << sizeof(wchar_t*) << std::endl;
	std::cout << sizeof(float*) << std::endl;
	std::cout << sizeof(double*) << std::endl;
	std::cout << sizeof(bool*) << std::endl;
	std::cout << sizeof(void*) << std::endl;
	return 0;
}

/*
What are the sizes of pointers in 32-bit and 64-bit applications?
- Regardless of the data type the pointer points to:
  in a 32-bit application, pointers are 4 bytes in size and
  in a 64-bit application, pointers are 8 bytes in size.
*/