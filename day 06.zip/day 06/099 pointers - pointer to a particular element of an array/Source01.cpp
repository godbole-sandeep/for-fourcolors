int main() {
	int a[] = { 1, 2, 3 };
	int* pa = &a[1];
	return 0;
}

/*
What is the key point to note in the program above?
- The pointer `pa` is set to point to the second element of the array
  rather than the beginning of the array.
*/