void AssignTen();

int main() {
	var = 5;
	AssignTen();
	return 0;
}

void AssignTen() {
	var = 10;
}


/*
What is a global variable?
- A global variable in C++ is a variable declared outside all functions,
  typically at the top of a program file.
- It is accessible from any function within the same file.
- For example, 'var' is a global variable.
- Global variables have a global scope, meaning they can be accessed from any function
  in the application.
- They have a static lifetime, meaning they exist for the entire duration of the
  application�s execution.
- Global variable is stored in the data segment of memory.

What caution should be observed while using global variables?
- Since global variabls can be accessed from any function, they can be modified
  from anywhere in the application, which can lead to potential side effects if
  not managed carefully.
- Therefore, use global variables sparingly.
- Overuse can make debugging and maintaining the code difficult.
*/
