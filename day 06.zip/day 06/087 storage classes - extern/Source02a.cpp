#include "globals.h"

// Global variable definition
int var = 1;

int main() {
	var = 5; // Accessing and modifying global variable
	AssignTen();
	AssignFifteen();
	AssignTwenty();
	return 0;
}

void AssignTen() {
	var = 10; // Accessing and modifying global variable
}

/*
How do I access global variables in a multi-source file setup?
- To access global variables in a multi-source file setup in C++,
  you can use the 'extern' keyword.
- This allows you to define a global variable in one source file and
  use it in other source files.
- The global variable declaration is typically placed in a header file.
- For example, in this case, `globals.h` contains the global variable declaration.
- The global variable must be defined in one of the source files.
- Note that there should be only one definition of the global variable.
- Defining global variables in multiple source files will result in a linking error.
- Note that global variables can be declared, but local variables cannot.
- Local variables can only be defined.

What is the difference between a declaration and a definition?
- Declaration informs the compiler of the existence of a variable or function and
  its type, without allocating storage or providing the full implementation.
- Definition allocates storage for variables or provides the full implementation
  of functions
- In other words, memory is allocated when a symbol is defined, but not when
  it is declared.
*/