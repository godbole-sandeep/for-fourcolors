int main() {
	// 1. Pointer Arithmetic and Assignment:
	int a[] = { 1, 2, 5 };
	int* pa = &a[1];
	pa = pa + 1;
	pa = pa - 2;

	// 2. Pointer Operations
	int* pb = ++pa;
	pb = pa++;
	pb = pa--;
	pb = --pa;

	// 3. Pointer Differences
	pa = &a[0];
	pb = &a[2];
	int diff = pb - pa;

	// 4. Pointer Dereferencing and Incrementing / Decrementing
	int n = 0;
	pa = &a[1];
	n = ++ * pa;
	n = *++pa;

	// 5. Postfix and Prefix Operations
	pa = &a[0];
	n = *pa++;
	n = (*pa)++;

	// 6. Pointer Decrementing and Dereferencing
	pa = &a[1];
	n = -- * pa;
	n = *--pa;

	// 7. Postfix Decrement Operations
	pa = &a[2];
	n = *pa--;
	n = (*pa)--;

	// 8. Pointer Addition and Subtraction
	pa = &a[0];
	pa += 2;
	pa -= 1;

	return 0;
}

/*
What is the key point to note in the program above?
- Avoid using complex pointer arithmetic in your programs.
- It can be very intricate and hard to manage.
- Consider the above code as a mental exercise to understand
  pointer operations, but be cautious about applying such complex
  pointer manipulations in practical scenarios.

The provided C++ program demonstrates various operations involving
pointers and arrays. Here's a detailed breakdown:
- 1. Pointer Arithmetic and Assignment:
  int* pa = &a[1]; initializes pa to point to the second element of the array a.
  pa = pa + 1; advances pa to point to the third element of the array.
  pa = pa - 2; moves pa back to point to the first element of the array.

- 2. Pointer Operations:
  int* pb = ++pa; increments pa (now pointing to the second element) and assigns it to pb.
  pb = pa++; assigns pa (pointing to the second element) to pb, then increments pa.
  pb = pa--; assigns pa (now pointing to the third element) to pb, then decrements pa.
  pb = --pa; decrements pa (now pointing to the second element) and assigns it to pb.

- 3. Pointer Differences:
  pa = &a[0]; initializes pa to point to the first element.
  pb = &a[2]; initializes pb to point to the third element.
  int diff = pb - pa; computes the difference between the addresses of pb and pa, which is the number of elements between them.

- 4. Pointer Dereferencing and Incrementing/Decrementing:
  pa = &a[1]; initializes pa to point to the second element.
  n = ++*pa; increments the value pointed to by pa (second element), then assigns it to n.
  n = *++pa; increments pa to point to the third element, then assigns the value pointed to by pa to n.

- 5. Postfix and Prefix Operations:
  pa = &a[0]; initializes pa to point to the first element.
  n = *pa++; assigns the value pointed to by pa (first element) to n, then increments pa.
  n = (*pa)++; increments the value pointed to by pa (first element) and assigns the original value to n.

- 6. Pointer Decrementing and Dereferencing:
  pa = &a[1]; initializes pa to point to the second element.
  n = --*pa; decrements the value pointed to by pa (second element), then assigns it to n.
  n = *--pa; decrements pa to point to the first element, then assigns the value pointed to by pa to n.

- 7. Postfix Decrement Operations:
  pa = &a[2]; initializes pa to point to the third element.
  n = *pa--; assigns the value pointed to by pa (third element) to n, then decrements pa.
  n = (*pa)--; decrements the value pointed to by pa (second element) and assigns the original value to n.

- 8. Pointer Addition and Subtraction:
  pa = &a[0]; initializes pa to point to the first element.
  pa += 2; advances pa to point to the third element.
  pa -= 1; moves pa back to point to the second element.
*/