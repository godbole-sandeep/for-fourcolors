#include <iostream>

#define SIZE 3

int main() {
	typedef int* int_ptr;
	int a[SIZE] = { 1, 6, 3 };

	for (int_ptr pwalker = a, pend = a + SIZE; pwalker < pend; pwalker++) {
		std::cout << *pwalker << std::endl;
	}

	return 0;
}

/*
Can pointer variables be compared?
- Yes, pointer variables can be compared.
- You can use relational operators like ==, !=, <, <=, >, and >= to compare pointers.
- Such comparisons are valid only if the pointers are pointing to elements within
  the same array.
*/