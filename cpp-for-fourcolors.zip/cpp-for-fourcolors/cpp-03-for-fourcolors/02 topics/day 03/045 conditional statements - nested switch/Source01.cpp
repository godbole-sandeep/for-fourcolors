#include <iostream>

int main() {
    int season = 2;
    int month = 4;
    switch (season) {
    case 1:
        switch (month) {
        case 1:
            std::cout << "January" << std::endl;
            break;
        case 2:
            std::cout << "February" << std::endl;
            break;
        default:
            std::cout << "Invalid month" << std::endl;
        }
        break;
    case 2:
        switch (month) {
        case 3:
            std::cout << "March" << std::endl;
            break;
        case 4:
            std::cout << "April" << std::endl;
            break;
        default:
            std::cout << "Invalid month" << std::endl;
        }
        break;
    default:
        std::cout << "Invalid season" << std::endl;
    }
    return 0;
}

/*
What is the syntax for writing nested switch statement?
- switch (expression1) {
  case value1:
      switch (expression2) {
      case value2:
          // Code block for expression1 = value1 and expression2 = value2
          break;
          // Additional cases for expression2...
      default:
          // Code block for inner switch default case
      }
      break;
  // Additional cases for expression1...
  default:
     // Code block for outer switch default case
  }
- In this syntax: The outer switch statement evaluates expression1.
- Inside each case block of the outer switch statement, there's another switch statement that
  evaluates expression2.
- Each inner switch statement can have its own set of case labels and a default case.
- The break statement in each inner switch statement is used to exit the inner switch and
  continue execution after the outer switch.
- The break statement after each outer case block is used to prevent fall-through to
  subsequent outer cases.
- This syntax allows you to handle more complex nested conditions by nesting switch statements
  inside each other, providing a structured way to handle multiple levels of decision-making in your code.
*/
