#include <iostream>

int main() {
    return 0;
}

/*
What is the syntax of an if-else statement?
- The syntax of an if-else statement is as follows:
  if (condition) {
      // Code block to execute if condition is true
  } else {
      // Code block to execute if condition is false
  }
  where,
  The 'condition' is a boolean expression that evaluates to either true or false.
  If the 'condition' is true, the code block immediately following the if statement is executed.
  If the 'condition' is false, the code block immediately following the else keyword is executed.

How does the above mentioned program work?
- If the condition (num % 2 == 0) evaluates to true, the code block immediately following the 
  if statement (enclosed within curly braces {}) is executed. The message "Number is even." is 
  then printed to the console. Conversely, if the condition evaluates to false, indicating that num is
  not divisible by 2 without any remainder, the else block is executed. In this case, the message
  "Number is odd." is printed to the console."
 */