#include <iostream>

int main() {
    int score = 85;

    return 0;
}

/*
What is the syntax of a if-else if-else ladder?
- The syntax of an if-else if-else ladder is as follows:
  if (condition1) {
      // Code block to execute if condition1 is true
  } else if (condition2) {
      // Code block to execute if condition2 is true
  } else if (condition3) {
      // Code block to execute if condition3 is true
  } else {
      // Code block to execute if none of the above conditions are true
  }
  In an if-else if-else ladder:
  The if statement is followed by an initial condition and its associated code block.
  After the initial if statement, any number of else if statements can follow, each with its
  own condition and associated code block.
  The conditions are evaluated sequentially from top to bottom. If a condition evaluates to true, the
  associated code block is executed, and the rest of the ladder is skipped.
  If none of the conditions in the ladder evaluates to true, the code block associated with the
  else statement (if present) is executed.

How does the above mentioned program work?
- This code snippet utilizes an if-else if-else ladder to determine a student's grade based on their
  score. Starting with the highest grade, the program checks if the score is greater than or equal to
  90, printing "Grade: A" if true. If the score doesn't meet this condition, it proceeds to check if it's
  greater than or equal to 80, printing "Grade: B" if true. Similarly, it checks for a score greater than
  or equal to 70, printing "Grade: C" in such cases. If none of these conditions are met, implying a
  score below 70, the program defaults to printing "Grade: D". This structured approach ensures
  that the appropriate grade is determined based on the score, providing clarity and consistency in grading.

*/