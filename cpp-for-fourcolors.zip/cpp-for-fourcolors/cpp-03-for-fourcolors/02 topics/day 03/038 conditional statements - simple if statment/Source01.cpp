#include <iostream>

int main() {
	return 0;
}

/*
What is the syntax of a simple if statement?
- The syntax of a simple if statement is as follows:
  if (condition) {
	  // Code block to execute if the condition is true
  }
  where,
  The 'condition' is a boolean expression that evaluates to either true or false.
  If the 'condition' is true, the code block enclosed within the curly braces {} is executed.
  If the 'condition' is false, the code block is skipped, and the program continues executing
  the code following the if statement.

How does the above mentioned program work?
- When you run above mentioned program, the if statement checks whether the value of num (which is 10) is greater than 5.
  Since this condition is true, the code block inside the if statement is executed. Conversely, if you set num
  to a number less than 5, the condition evaluates to false, and as a result, the code block inside the
  if statement is skipped.

What is a pair of '{ }' referred to as?
- A pair of curly braces '{ }' is known as 'block delimiters'.

When is it mandatory to use block delimiters in programming statements like
'if', 'else', 'for', 'while', or 'do-while'?
- Block delimiters are mandatory when the body of the 'if', 'else', 'for', 'while', or 'do-while'
  statements contains multiple statements. If the body conprises of single statement, block-delimers
  can be skipped.
*/