#include <iostream>

int main() {
    for (int i = 1; i <= 10; ++i) {
        if (i % 2 == 0) { // Check if even
            std::cout << "First even number found: " << i << std::endl;
            break; // Exit the loop after finding one even number
        }
    }
    return 0;
}
/*
What does the break statement do?
- In a loop (such as for, while, or do-while), the break statement causes the loop to terminate prematurely.
  Control passes to the statement following the loop.
- In a switch statement, the break statement is used to exit the switch block.
  It prevents fall-through to subsequent case labels and transfers control
  to the statement following the switch block.
*/