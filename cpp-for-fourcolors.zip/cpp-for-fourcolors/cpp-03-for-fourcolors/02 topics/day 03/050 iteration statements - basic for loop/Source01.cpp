#include <iostream>

int main() {

    return 0;
}

/*
What is the syntax of the basic for loop?
- The syntax of the basic for loop is as follows:
  for (initialization; condition; update) {
      // Code block to execute
  }
- In this syntax: The for keyword is followed by three parts enclosed in parentheses ( ):
  initialization, condition, and update.
- The initialization part initializes a loop control variable, typically used to control the loop iteration.
- The condition part specifies the condition under which the loop continues executing. If the
  condition evaluates to false, the loop terminates.
- The update part modifies the loop control variable after each iteration of the loop.
- After each iteration, the loop checks the condition. If the condition is true, the loop continues
  executing. If the condition is false, the loop terminates.
- The code block within the curly braces { } contains the statements to be executed repeatedly
  as part of the loop.
- This syntax provides a concise way to define and control loops in C++, making it easy to perform
  repetitive tasks with specified conditions and iterations.
- Note that the three parts of the for loop are not mandatory.
  for (; ; ) {
      // Code block to execute
  }
  This for loop is a valid loop. It turns out to be an infinite loop.
*/