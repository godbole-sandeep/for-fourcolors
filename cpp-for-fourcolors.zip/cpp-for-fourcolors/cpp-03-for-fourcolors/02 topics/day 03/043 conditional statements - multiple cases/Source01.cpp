#include <iostream>


int main() {
    char grade = 'B';
    switch (grade) {
    case 'A':
    case 'B':
        std::cout << "Excellent!" << std::endl;
        break;
    case 'C':
    case 'D':
        std::cout << "Well done!" << std::endl;
        break;
    default:
        std::cout << "Invalid grade" << std::endl;
    }
    return 0;
}

/*
What is the syntax for writing switch with multiple case labels?
- The syntax for writing a switch statement with multiple case labels is as follows:
  switch (expression) {
  case value1:
  case value2:
  case value3:
      // Code block to execute if expression matches value1, value2, or value3
      break;
  // Additional cases...
  default:
      // Code block for default case
  }
  In this syntax:
  Each case label (value1, value2, value3, etc.) represents a possible value of the expression.
  If the expression matches any of the listed case labels, the associated code block is executed.
  There's only one code block for all the listed case labels, and it is terminated by a break
  statement to prevent fall-through to the next case.
  The default case is optional and executed if the expression does not match any of the listed case labels.

Explain the working of the code above.
- This code snippet employs a switch statement to determine a message based on the value of the
  variable grade. If grade matches either 'A' or 'B', the message "Excellent!" is printed to the
  console. Similarly, if grade matches 'C' or 'D', the message "Well done!" is printed. If grade
  does not match any of these cases, the default case is executed, printing "Invalid grade". This
  structured approach efficiently handles multiple possible values of grade and provides
  appropriate feedback based on its value.
*/
