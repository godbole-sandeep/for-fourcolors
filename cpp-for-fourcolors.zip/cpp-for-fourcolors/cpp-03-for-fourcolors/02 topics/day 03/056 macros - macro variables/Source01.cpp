
/*
- When program is compiled, preprocessor replaces macro variables by their corresponding value.
- Note macro variable is not a memory variable hence no memory is reserved for macro variable.
- Macro variable improves program readability and maintenance.
*/
