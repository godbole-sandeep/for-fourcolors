#include <iostream>

#define VIEW_PROFILE 1
#define EDIT_PROFILE 2
#define VIEW_MESSAGE 3
#define LOGOUT 4

int main() {
    int choice;

    // Display menu options
    std::cout << "Choose an option:\n";
    std::cout << "1. View profile\n";
    std::cout << "2. Edit profile\n";
    std::cout << "3. View messages\n";
    std::cout << "4. Logout\n";

    // Get user's choice
    std::cin >> choice;

    // Process user's choice using switch statement
    switch (choice) {
    case VIEW_PROFILE:
        std::cout << "Viewing profile...\n";
        // Code to display user's profile
        break;
    case EDIT_PROFILE:
        std::cout << "Editing profile...\n";
        // Code to allow user to edit profile
        break;
    case VIEW_MESSAGE:
        std::cout << "Viewing messages...\n";
        // Code to display user's messages
        break;
    case LOGOUT:
        std::cout << "Logging out...\n";
        // Code to log out the user
        break;
    default:
        std::cout << "Invalid choice!\n";
        // Code to handle invalid choices
        break;
    }

    return 0;
}

/*
- The case statements are friendly now.
*/