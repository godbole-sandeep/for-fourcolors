#include <iostream>

int main() {
    int choice;

    // Display menu options
    std::cout << "Choose an option:\n";
    std::cout << "1. View profile\n";
    std::cout << "2. Edit profile\n";
    std::cout << "3. View messages\n";
    std::cout << "4. Logout\n";

    // Get user's choice
    std::cin >> choice;

    // Process user's choice using switch statement
    switch (choice) {
    case 1:
        std::cout << "Viewing profile...\n";
        // Code to display user's profile
        break;
    case 2:
        std::cout << "Editing profile...\n";
        // Code to allow user to edit profile
        break;
    case 3:
        std::cout << "Viewing messages...\n";
        // Code to display user's messages
        break;
    case 4:
        std::cout << "Logging out...\n";
        // Code to log out the user
        break;
    default:
        std::cout << "Invalid choice!\n";
        // Code to handle invalid choices
        break;
    }

    return 0;
}

/*
- The case statements are not friendly.
*/