#include <iostream>

int main() {
    int count = 0;

    return 0;
}

/*
What is the syntax of the basic do-while loop?
- The syntax of the basic do-while loop is as follows:
  do {
      // Code block to execute
  } while (condition);
- In this syntax: The do keyword is followed by a code block enclosed in curly braces { }.
- The code block is executed once initially, before checking the loop condition.
- After executing the code block, the loop checks the condition specified in the while statement.
- If the condition evaluates to true, the loop repeats, executing the code block again.
- If the condition evaluates to false, the loop exits, and control continues with the statement
  following the do-while loop.
- This syntax ensures that the code block is executed at least once, regardless of the initial
  condition. After the first iteration, the loop continues to execute as long as the specified condition
  remains true.
*/