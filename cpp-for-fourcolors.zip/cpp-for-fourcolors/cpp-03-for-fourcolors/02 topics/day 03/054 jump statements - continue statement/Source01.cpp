#include <iostream>

int main() {
    for (int i = 1; i <= 10; ++i) {
        if (i % 2 == 0) { // Check if even
            continue;
        }
        std::cout << i << " "; // Print only odd numbers
    }
    std::cout << std::endl;
    return 0;
}

/*
What does the continue statement do?
- The continue statement is used in loops such as for, while, or do-while.
- When the continue statement is encountered within a loop, the control immediately
  jumps to the loop's increment (or update) step (in the case of for loops), or to the loop's
  condition evaluation step (in the case of while and do-while loops), bypassing any remaining
  statements within the loop's body.
*/