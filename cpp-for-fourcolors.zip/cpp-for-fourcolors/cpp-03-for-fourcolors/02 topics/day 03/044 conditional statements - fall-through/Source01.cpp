#include <iostream>


int main() {
    int month = 2;
    switch (month) {
    case 1:
        std::cout << "January" << std::endl;
    case 2:
        std::cout << "February" << std::endl;
        break;
    case 3:
        std::cout << "March" << std::endl;
        break;
    default:
        std::cout << "Invalid month" << std::endl;
    }
    return 0;
}

/*
What is the syntax for writing switch with fall-through?
- The syntax for writing a switch statement with fall-through is as follows:
  switch (variable) {
  case value1:
      // Code block for value1
  case value2:
      // Code block for value1 and value2 (fall-through)
  case value3:
      // Code block for value1, value2, and value3 (fall-through)
      break;
  // Additional cases...
  default:
      // Code block for default case
  }
- In this syntax:
  After executing the code block associated with a case label (value1), the program continues to
  execute the code blocks for subsequent case labels (value2, value3, etc.) until a break
  statement is encountered.
  
  The absence of a break statement after each case label (except for the last one) results in fall-through
  behavior, where control flows from one case label to the next.

  The last case label (value3 in this example) should have a break statement to terminate the
  switch statement and prevent further fall-through.

  This syntax allows you to execute the same code block for multiple case labels, reducing code
  duplication in situations where multiple cases should have the same behavior. However, it's
  essential to use fall-through deliberately and ensure it doesn't lead to unintended behavior.
*/
