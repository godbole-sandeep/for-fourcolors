#include <iostream>

int main() {
    int day = 3;

    return 0;
}

/*
What is the syntax of a basic switch statement?
- The syntax of a basic switch statement is as follows:
  switch (expression) {
      case value1:
          // Code block to execute if expression equals value1
          break;
      case value2:
          // Code block to execute if expression equals value2
          break;
      // More cases...
      default:
          // Code block to execute if expression does not match any case
  }
  In a switch statement:
  The switch keyword is followed by an expression in parentheses ( ).
  The case labels represent possible values of the expression.
  If the expression matches a case label, the code block associated with that case label is executed.
  The break statement is used to exit the switch statement and prevent fall-through to the next case.
  The default case is optional and executed if the expression does not match any of the case labels.
  The default case can be placed anywhere within the switch statement, and it will still function correctly.
  If the default case is placed anywhere within the switch statement other than at the end, then it
  requires to be properly terminated with break statement.
- While it's allowed to place the default case anywhere within the switch statement, it's generally
  recommended to follow common conventions which is placing it at the end of switch statement.

How does the above mentioned program work?
- The code snippet utilizes a switch statement to print the name of the day corresponding to the
  value of the variable day. The switch statement evaluates the value of day and matches it with
  the appropriate case label. If day equals 1, "Monday" is printed; if day equals 2, "Tuesday"
  is printed; and if day equals 3, "Wednesday" is printed. If day does not match any of these
  cases, the default case is executed, printing "Invalid day". This structured approach efficiently
  handles multiple possible values of day and provides a clear output based on the value of the variable.
*/
