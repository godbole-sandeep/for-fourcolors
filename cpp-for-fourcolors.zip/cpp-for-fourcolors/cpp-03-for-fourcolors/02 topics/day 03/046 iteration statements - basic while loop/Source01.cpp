#include <iostream>

int main() {
    int count = 0;

    // Basic while loop

    return 0;
}

/*
What is the syntax of the basic while loop?
- The syntax of the basic while loop in C++ is as follows:
  while (condition) {
    // Code block to execute while condition is true
  }
- In this syntax: The while keyword is followed by a condition enclosed in parentheses ( ).
- The condition is evaluated before each iteration of the loop.
- If the condition evaluates to true, the code block immediately following the while statement
  (within curly braces { }) is executed.
- After executing the code block, control returns to the while statement to re-evaluate the condition.
- If the condition evaluates to false, the loop exits, and control continues with the statement
  following the while loop.
- This syntax allows you to repeatedly execute a block of code while a specified condition remains
  true, providing a way to perform iterative tasks in your program.
*/