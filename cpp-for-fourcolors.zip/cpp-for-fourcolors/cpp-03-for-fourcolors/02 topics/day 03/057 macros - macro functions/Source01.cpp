
/*
- When program is compiled, preprocessor replaces macro function with its corresponding code.
- Many leading frameworks use macro functions for code substitution. For ex. ATL, MFC, CAA etc.
*/
