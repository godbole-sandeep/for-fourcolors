#include <iostream>

int main() {
    // Infinite for loop
    for (;;) {
        std::cout << "This loop runs indefinitely!" << std::endl;
    }

    // The code here will never be reached
    std::cout << "This line will never be printed." << std::endl;

    return 0;
}

/*
- In this example, there are no initialization, condition, or update statements within the for loop
  declaration. As a result, the loop will run indefinitely, executing the code block repeatedly.
*/