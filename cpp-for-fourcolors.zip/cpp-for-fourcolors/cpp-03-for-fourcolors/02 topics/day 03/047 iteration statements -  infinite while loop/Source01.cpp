#include <iostream>

int main() {
    // Infinite while loop
    while (true) {
        std::cout << "This loop runs indefinitely!" << std::endl;
    }

    // The code here will never be reached
    std::cout << "This line will never be printed." << std::endl;

    return 0;
}
