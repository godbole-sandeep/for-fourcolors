#include <iostream>

int main() {
    int rows = 5, cols = 5;
    int targetRow = 2, targetCol = 3;

    // Nested loop to iterate over rows and columns
    for (int row = 0; row < rows; ++row) {
        for (int col = 0; col < cols; ++col) {
            std::cout << "(" << row << "," << col << ") ";
            if (row == targetRow && col == targetCol) {
                goto endLoop; // Jump to the end of the loop
            }
        }
        std::cout << std::endl;
    }

    // Label to jump to when breaking the loop
endLoop:
    std::cout << "\nLoop exited at target position (" << targetRow << "," << targetCol << ")." << std::endl;

    return 0;
}

/*
- One use of goto is to break nested loops prematurely.
*/