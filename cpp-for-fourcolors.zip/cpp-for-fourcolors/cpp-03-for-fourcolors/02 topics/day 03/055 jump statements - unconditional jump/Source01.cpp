#include <iostream>

int main() {
	std::cout << "Hello, World" << std::endl;
	std::cout << "Exiting the Program" << std::endl;
	return 0;
}

/*
- Hello, World is displayed everytime program is executed.
*/