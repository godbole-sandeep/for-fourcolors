#include <iostream>


int main() {
	std::cout << "Hello, World" << std::endl;
	std::cout << "Exiting the Program" << std::endl;
	return 0;
}

/*
- Avoid using goto statement in a program.
- If at all you want to use goto, use it only for forward jump.
- A goto statement that jumps backward creates a loop.
- Too many goto statements are likely to create spaghetti code.
*/