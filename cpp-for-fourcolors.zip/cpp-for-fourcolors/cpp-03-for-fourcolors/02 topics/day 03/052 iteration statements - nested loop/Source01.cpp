#include <iostream>

int main() {
    // Outer loop to iterate over rows
    for (int i = 1; i <= 3; i++) {
        // Inner loop to iterate over columns
        for (int j = 1; j <= 3; j++) {
            std::cout << "(" << i << "," << j << ") "; // Print coordinates
        }
        std::cout << std::endl; // Move to the next line after each row
    }

    return 0;
}

/*
What are nested loops?
- Nested loops are loops within loops.
*/