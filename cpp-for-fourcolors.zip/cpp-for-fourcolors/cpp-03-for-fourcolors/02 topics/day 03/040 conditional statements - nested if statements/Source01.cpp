#include <iostream>

int main() {

    return 0;
}

/*
What is the syntax of a nested if statement?
- The syntax of a nested if statement is as follows:
  if (condition1) {
      // Code block for the outer if statement
      if (condition2) {
          // Code block for the inner if statement
      }
  }
  In a nested if statement:
  The outer if statement contains its own condition and code block.
  Inside the code block of the outer if statement, there's another
  if statement (the inner if statement) with its own condition and code block.
  The inner if statement can itself contain further nested if statements,
  creating multiple levels of nesting if needed.

How does the above mentioned program work?
- The outer if statement checks whether the value of num is greater than 0. If the condition
  num > 0 is true, the code block associated with the outer if statement will be executed.
  Inside this code block, there's an inner if statement. The inner if statement checks whether
  the value of num is even (num % 2 == 0). If this condition is true, indicating that num is even,
  the code block associated with the inner if statement will be executed, and the message
  "Positive even number." will be printed to the console. If the condition is false, indicating that num
  is odd, the code block associated with the else statement will be executed, and the message
  "Positive odd number." will be printed to the console. If num is not greater than 0, none of the
  code inside the outer if statement will be executed.
*/