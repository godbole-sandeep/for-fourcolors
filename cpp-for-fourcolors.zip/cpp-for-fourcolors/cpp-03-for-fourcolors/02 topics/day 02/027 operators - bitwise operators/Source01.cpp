int main() {
	int a = 5;  // Binary representation: 0000 0101
	int b = 3;  // Binary representation: 0000 0011

	/* Bitwise AND (&) */

	/* Bitwise OR (|) */

	/* Bitwise XOR (^) */

	/* Bitwise NOT (~) */

	/* Bitwise Left Shift (<<) */

	/* Bitwise Right Shift (<<) */

	return 0;
}

/*
What are the bitwise operators?
- Bitwise operators are the operators that operates on individual bits of integer operands.
- These operators manipulate the binary representations of integers at the bit level.
- The bitwise operators in C++ are:
  Bitwise AND (&)
  Bitwise OR (|)
  Bitwise XOR (^)
  Bitwise NOT (~)
  Left shift (<<)
  Right shift (>>)
- Bitwise operators except 'bitwise NOT' are binary, which means they require two arguments to operate.
- Bitwise NOT is a unary operator.

What's the general syntax for bitwise operations?
- The general syntax for bitwise operators except bitwise NOT is: operand1 bitwise_operator operand2 where
  'operand1' and 'operand2' can be variables, constants, or expressions.
  'bitwise_operator' is one of the bitwise operators such as & (AND), | (OR), ^ (XOR), << (left shift), or
  >> (right shift).
- The general syntax for bitwise NOT is ~variable.

What does the bitwise AND (&) operator do?
- The bitwise AND (&) operator performs a bitwise AND operation between
  corresponding bits of two integer operands. 
- It evaluates to 1 if both bits are 1; otherwise, it evaluates to 0.

What does the bitwise OR (|) operator do?
- The bitwise OR (|) operator performs a bitwise OR operation between
  corresponding bits of two integer operands.
- It evaluates to 1 if at least one of the bits is 1; otherwise, it evaluates to 0.

What does the bitwise XOR (^) operator do?
- The bitwise XOR (^) operator performs a bitwise XOR (exclusive OR) operation between
  corresponding bits of two integer operands.
- It evaluates to 1 if the bits are different, and it evaluates to 0 if the bits are the same.

What does the bitwise NOT (~) operator do?
- The bitwise NOT (~) operator performs a bitwise complement operation on each bit of the operand.
- It flips each bit from 0 to 1 and from 1 to 0.

What does the bitwise Left shift (<<) operator do?
- The bitwise left shift (<<) operator shifts the bits of the left operand to the left by
  a number of positions specified by the right operand.

What does the bitwise Right shift (>>) operator do?
- The bitwise right shift (>>) operator shifts the bits of the left operand to the right by
  a number of positions specified by the right operand.
*/