int main() {
	return 0;
}

/*
What is '?:' operator known as?
- The ?: operator is known as the ternary conditional operator.
- It's called "ternary" because it takes three operands.
- It's the only ternary operator in C++.
- The ternary conditional operator provides a concise way to write
  conditional expressions in C++.

What is the general syntax for the ternary conditional operator?
- The general syntax for the ternary conditional operator is:
  condition ? expression1 : expression2
  If condition evaluates to true (non-zero), expression1 is evaluated and returned.
  If condition evaluates to false (zero), expression2 is evaluated and returned.
*/
