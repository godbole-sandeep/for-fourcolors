int main() {
	return 0;
}

/*
What is a comma operator?
- The comma operator separates expressions inside bigger expressions.
- It evaluates each of its operands (from left to right) and returns the value of the last operand.

What is the general syntax for the comma operator?
- The general syntax for the comma operator is: expression1, expression2, expression3, ..., expressionN; where
  'expression1', 'expression2', ..., 'expressionN' are the expressions separated by commas. 
*/