int main() {
    int a = 5;
    int b = 3;
    int c = 0;
    c = a + b; // simple expression
    return 0;
}

/*
What is a simple expression?
- A simple expression is an expression which consists of a single operator and
  operands of the same type.
*/