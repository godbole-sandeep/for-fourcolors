#include <iostream>

int main() {
    // Variable defined at the beginning of the block
    int outerVariable = 10;
    std::cout << "Outer variable: " << outerVariable << std::endl;

    // Variable defined in the middle of the block
    int middleVariable = 15;
    std::cout << "Middle variable: " << middleVariable << std::endl;

    // Variable defined at the end of the block
    int innerVariable = 20;
    std::cout << "Inner variable: " << innerVariable << std::endl;

    return 0;
}

/*
Is it necessary to define all needed variables at the beginning of a function?
- Absolutely not.
- Variables can be defined anywhere within a block, including nested blocks.
- The definition, however, must appear before using the variable.
*/