int main() {
    int a = 5;
    int b = 3;
    int c = 7;
    int result = 0;
    result = (a + b) * (c - a) / b + (c % a); // complex expression by mixed operators

    int i = 5;
    double j = 3.5;
    char k = 'A';
    result = i * j + k; // complex expression by mixed operators and data types

    return 0;
}

/*
What is a complex expresion?
- A complex expression is an expression that consists of multiple operators of different
  precedance and associative order and/or operands of similar or dissimilar data types.
*/