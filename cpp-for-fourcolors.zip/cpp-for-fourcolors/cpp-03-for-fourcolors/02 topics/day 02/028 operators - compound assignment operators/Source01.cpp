int main() {
	/* Addition and Assignment (+=) */

	/* Subtraction and Assignment (-=) */

	/* Multiplication and Assignment (*=) */

	/* Division and Assignment (/=) */

	/* Modulus and Assignment (%=) */

	/* Bitwise AND and Assignment (&=) */

	/* Bitwise OR and Assignment (|=) */

	/* Bitwise XOR and Assignment (^=) */

	return 0;
}

/*
What are compound assignment operators?
- Compound assignment operators are shorthand notations that combine an arithmetic or
  bitwise operation with an assignment.
- In C++, the compound assignment operators include:
  Addition and Assignment (+=)
  Subtraction and Assignment (-=)
  Multiplication and Assignment (*=)
  Division and Assignment (/=)
  Modulus and Assignment (%=)
  Bitwise AND and Assignment (&=)
  Bitwise OR and Assignment (|=)
  Bitwise XOR and Assignment (^=)
  Bitwise Left Shift and Assignment (<<=)
  Bitwise Right Shift and Assignment (>>=)
- They allow you to perform an operation on a variable and assign the result back to
  the same variable in a single step.

What is the general syntax for compound assignment operators?
- The general syntax of compound assignment operators is: variable operator= expression; where
  'variable' is the variable to be updated.
  'operator' is an arithmetic or bitwise operator.
  'expression' is the value or expression to perform the operation with.
*/