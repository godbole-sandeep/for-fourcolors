#include <iostream>

int main() {
    int x = 5;
    int y = 3;
    bool result1 = (x > 0) && (y > 0); // true if both x and y are positive
    bool result2 = (x < 0) || (y < 0); // true if either x or y is negative
    bool result3 = !(x == y); // true if x is not equal to y

    std::cout << "Result 1: " << result1 << std::endl;
    std::cout << "Result 2: " << result2 << std::endl;
    std::cout << "Result 3: " << result3 << std::endl;

    return 0;
}

/*
What are logical operators used for?
- Logical operators integrate results from several conditions into a single outcome.
- The main logical operators are: AND (&&), OR (||) and NOT(!).
- AND (&&), OR (||) and NOT(!) are binary operators, meaning that they require two arguments.
- The arguments must be boolean expressions or expressions that can be implicitly converted to boolean values.
- These expressions can include:
  Boolean variables: Variables of type bool.
  Boolean constants: Constants true and false.
  Comparison expressions: Expressions that evaluate to boolean values,
                          such as comparisons using relational operators (<, >, <=, >=, ==, !=).
  Function calls: Functions that return boolean values.

How do AND (&&), OR (||) and NOT(!) work?
- The AND (&&) operator returns true if both operands are true, otherwise it returns false.
- The OR (||) operator returns true if at least one of the operands is true, otherwise it returns false.
- The NOT operator negates the value of its operand. If the operand is true, it returns false, and
  if the operand is false, it returns true.

The AND (&&) and OR (||) operators are considered smart operators. What does this mean?
- The following is the reason why these operators are considered as smart operators.
- When using the && operator, if the left operand evaluates to false, the right operand
  is not evaluated because the overall result will always be false regardless of the right
  operand's value. 
- Similarly, when using the || operator, if the left operand evaluates to true, the right
  operand is not evaluated because the overall result will always be true regardless of the
  right operand's value.

In a boolean expression, what boolean value is the number zero converted to?
- The number 0 is converted to boolean value 'false'.

In a boolean expression, what boolean values are the +ve and -ve numbers converted to?
- The +ve and -ve numbers are converted to boolean value 'true'.
- Thus, in terms of boolean expressions, both +5 and -10 are considered as 'true' values.
*/