int main() {
    int i = 5;
    double j = 3.5;
    char k = 'A';
    int result = i * j + k;
    return 0;
}

/*
Does expressions have a type?
- Yes, expressions have types.

How to determine the type of an expression?
- The type of an arithmetic expression is determined by the types of its operands and
  the rules of implicit type conversion.
- For example, if you have an expression '5 + 3', both operands are integers,
  so the expression evaluates to an integer. 
- If you have an expression '3.5 + 2', one operand is a double,
  so the expression evaluates to a double.

What is the data type of the expression 'i * j + k'?
- It is double.

Is the type of the 'result' variable correct?
- Since the type of the expression 'i * j + k' evaluates to 'double',
  the type of the variable 'result' should also be 'double'.
- If, however, the developer wanted the type of the 'result' variable to be an integer,
  then a explicit type casting is required to convert the result of an expression from
  a double to an integer.
- If explicit type casting is not done, then the compiler is likely to throw a warning.
*/