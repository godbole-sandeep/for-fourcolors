int main() {
	int a = 5, b = 0;
	return 0;
}