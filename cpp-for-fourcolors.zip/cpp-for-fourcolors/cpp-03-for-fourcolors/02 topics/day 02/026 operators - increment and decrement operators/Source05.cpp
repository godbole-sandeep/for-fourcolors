int main() {
	/* Pre-increment (++i): */
	int a = 5;
	int b = ++a; // 'a' is incremented to 6, then assigned to 'b'
	// Now a = 6, b = 6

	/* Pre-decrement (--j): */
	int i = 5;
	int j = --i; // 'i' is decremented to 4, then assigned to 'j'
	// Now i = 4, j = 4

	/* Post-increment (k++) */
	int p = 5;
	int q = p++; // First 'q' gets the value of 'p' (5), then 'p' is incremented to 6
	// Now p = 6, q = 5

	/* Post-decrement (m--) */
	int x = 5;
	int y = x--; // First 'y' gets the value of 'x' (5), then 'x' is decremented to 4
	// Now x = 4, y = 5

	return 0;
}

/*
What are the pre-increment and pre-decrement operators?
- The general syntax for pre-increment is ++variable and
  for pre-decrement is --variable.
- Pre-increment and pre-decrement operators are unary operators in C++.
- The pre-increment and pre-decrement operators change the value of a variable
  by 1 before it is used in an expression.
- Pre-increment operation such as 'y = ++x;' is equivalent to
  x = x + 1; // first increment
  y = x; // then assignment
- Pre-decrement operation such as 'y = --x;' is equivalent to
  x = x - 1; // first decrement
  y = x; // then assignment
- Pre-increment and pre-decrement operators are unary,
  which means they require one argument to operate.

What are the post-increment and post-decrement operators?
- The general syntax for post-increment is variable++ and
  for post-decrement is variable++.
- Post-increment and post-decrement operators are unary operators in C++.
- The post-increment and post-decrement operators change the value of a variable
  by 1 after it is used in an expression.
- Post-increment operation such as 'y = x--;' is equivalent to
  y = x; // first assignment
  x = x + 1; // then increment
- Post-decrement operation such as 'y = x--;' is equivalent to
  y = x; // first assignment
  x = x - 1; // then decrement
- Post-increment and post-decrement operators are unary,
  which means they require one argument to operate.
*/