int main() {
	return 0;
}

/*
What are the arithmetic operators in C++?
- Arithmetic operators perform mathematical operations on variables and values.
- The main arithmetic operators in C++ are:
  Addition: +
  Subtraction: -
  Multiplication: *
  Division: /
  Modulus (remainder): %
- Arithmetic operators are binary, which means they require two arguments to operate.

What is the general syntax for arithmetic operators?
- The general syntax for arithmetic operators is: operand1 operator operand2 where
  'operand1' and 'operand2' can be variables, constants, or expressions.
  'operator' is one of the arithmetic operators such as +, -, *, /, or %.
*/