int main() {
	int dividend = 0, divisor = 0;
	int quotient = 0, remainder = 0;

	// Positive dividend and divisor
	dividend = 5;
	divisor = 3;
	quotient = dividend / divisor; // 1
	remainder = dividend % divisor; // 2 sign same as dividend

	// Negative dividend and positive divisor
	dividend = -5;
	divisor = 3;
	quotient = dividend / divisor; // -1
	remainder = dividend % divisor; // -2 sign same as dividend

	// Positive dividend and negative divisor
	dividend = 5;
	divisor = -3;
	quotient = dividend / divisor; // -1
	remainder = dividend % divisor; // 2 sign same as dividend

	// Negative dividend and divisor
	dividend = -5;
	divisor = -3;
	quotient = dividend / divisor; // 1
	remainder = dividend % divisor; // -2 sign same as dividend

	return 0;
}

/*
How does the modulus operator behave with signed arguments?
- In MSVC++, the modulus operator for positive and negative integers adheres to
  mathematical convention, with the output having the same sign as the dividend.
*/