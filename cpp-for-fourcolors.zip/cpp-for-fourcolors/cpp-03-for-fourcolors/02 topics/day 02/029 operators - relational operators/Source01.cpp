int main() {
	int u = 3;
	bool result = false;

	return 0;
}

/*
What are relational operators?
- Relational operators are those that compare the relationship between two operands.

What is the general syntax for relational operators?
- The general syntax for relational operators is as follows: operand1 operator operand2
- 'operand1' and 'operand2' are the operands being compared. 
  'operand1' and 'operand2' can be variables, constants or expressions.
  'operator' is one of the relational operators: ==, !=, >, <, >=, or <=.

What are the meanings of ==,!=, >, <, >=, and <= operators?
- '==' is used for determining if operand1 is equal to operand2. It's called Equality operator.
- '!=' is used for determining if operand1 is not equal to operand2. It's called Inquality operator.
- '<' is used for determining if operand1 is less than operand2. It's called Less Than operator.
- '>' is used for determining if operand1 is greater than operand2. It's called Greater Than operator.
- '<=' is used for determining if operand1 is less than or equal to operand2. It's called Less Than or Equal To operator.
- '>=' is used for determining if operand1 is greater than or equal to operand2. It's called Greater Than or Equal To operator.
*/