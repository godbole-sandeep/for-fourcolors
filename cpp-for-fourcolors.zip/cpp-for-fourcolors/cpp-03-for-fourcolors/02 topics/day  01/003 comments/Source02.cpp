#include <iostream>

/*
 This is a simple program to calculate simple interest
 Simple interest formula: SI = (P * R * T) / 100
 Where:
   SI is the simple interest
   P is the principal amount
   R is the rate of interest
   T is the time period
*/

int main() {
	float principal, rate, time, simple_interest;

	// Taking input from the user for principal amount, rate of interest, and time period
	std::cout << "Enter the principal amount: ";
	std::cin >> principal;  // Principal amount in dollars

	std::cout << "Enter the rate of interest (in percentage): ";
	std::cin >> rate;  // Rate of interest in percentage

	std::cout << "Enter the time period (in years): ";
	std::cin >> time;  // Time period in years

	// Calculating simple interest
	simple_interest = (principal * rate * time) / 100;

	// Displaying the calculated simple interest
	std::cout << "Simple Interest: " << simple_interest << std::endl;

	return 0;
}
