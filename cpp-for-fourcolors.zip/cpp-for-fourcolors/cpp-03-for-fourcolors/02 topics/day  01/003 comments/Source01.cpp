// single line comment

/*
multi
line
comment
*/

/*
What are comments?
- Comments are textual annotations(notes) within the source code that are ignored
  by the compiler during the compilation process.

What are the two main types of comments in C++?
- C++ supports two main types of comments: single-line and multi-line.

Single-line Comments
- The text in front of '//' is called as single line comment.
  The compiler ignores everything from the slashes to the end of the line.
  It's a handy way to explain your code or temporarily disable a piece of it.

Multi-line Comments
- Multi-line comments begin with / * and end with * /.
  Everything between these symbols is treated as a comment.

What are the applications of comments?
- Comments are useful when you want to provide more detailed explanations about the code. Or,
- When you want to temporarily exclude a block of code from being executed.

Does compiler ignores comments?
- Yes. Comments, whether single or multiline, are ignored by the compiler.
  
What are the shortcut keys for commenting or uncommenting code in Visual Studio?
- To comment a code, use: Ctrl + K, Ctrl + C
- To uncomment a code, use: Ctrl + K, Ctrl + U
*/