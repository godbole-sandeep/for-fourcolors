int main() {
	/* overflow case */
	int u = 2147483647;
	u = u + 1; // overflow happens here

	int v = -2147483648;
	v = v - 1; // underflow happens here
	
	return 0;
}

/*
What is overflow and underflow?
- Overflow and underflow are phenomena that occur when the result of a mathematical operation exceeds
  the representable range of a data type.

When does overflow occur?
- Overflow occurs when the result of a computation exceeds
  the maximum representable value for a given data type.

When does underflow occur?
- Underflow occurs when the result of a computation is smaller than
  the minimum representable value for a given data type.
*/
