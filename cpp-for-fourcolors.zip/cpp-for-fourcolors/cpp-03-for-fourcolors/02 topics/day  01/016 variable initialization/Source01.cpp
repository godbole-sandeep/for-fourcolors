int main() {
	return 0;
}

/*
What is initialization?
- Initialization is the process of assigning an initial value to a variable at the time of its definition.

Can a variable exist without initialization? Or
Can a variable exist without being assigned an initial value?
- Yes. However, it will be created with a garbage value.
*/
