int main() {
	return 0;
}

/*
What is a variable?
- In programming, a variable is like a labelled container that holds information or data.
- Think of it as a box with a label where you can store numbers, text, or other types of data.

How to visualize a variable?
- The graphics below demonstrate how to visualize a variable.
      +------+      +------+       +------+
    a |      |    b |      |     c |      |
	  +------+      +------+       +------+

What is the typical syntax for defining variables?
- Syntax: data_type variable_name; where,
  data_type: Specifies the type of data that the variable can hold.	  
  variable_name: is the name of the variable.
- Examples:
  int age;
  float interestRate; 
  char grade;

What does 'int a' implies to the compiler?
- The statement 'int a' tells to the compiler to
  create one variable whose name has to be 'a' and
  has to be suitable for storing integer.
- This statement is also called as definition of 'a'.

How many variables can be defined in one statement?
- In a statement we can define one or more variables.

What is the syntax for defining multiple variables in a single statement?
- Syntax: data_type variable1, variable2, ..., variableN; where,
  data_type: specifies the type of data for all variables.
  variable1, variable2,..., variableN: are the identifiers for the multiple variables, separated by commas.
- Examples:
  double c, d;
  int num1, num2, num3;
- When multiple variables are defined in a statement, they all will have same data type.

Where are these variables brought into existence?
- Variables are brough into existance in memory.

How much memory do variables require?
- It depends on the data type used to define the variable.
- For instance, defining variable 'a' as 'int a' would require 4 bytes since
  'int' requires 4 bytes.
- The meaning of each bit in 32-bits will be the same as specified by 'int'.
*/