int main() {
	int 1n;			
	int _1n;		
	int n1;			
	int emp	code;	
	int emp_code;	
	int empCode;	
	int if;			
	return 0;
}

/*
What are the rules for variable naming?
- It should not start with a number.
- It can start with either _ or the alphabet.
- Numbers can be specified starting with the second character.
- It should not include whitespace characters like space, tab, or new line.
- It should not be among the keywords.
- Remember that the C++ environment is case sensitive. C++ treats sum, sum, and SUM
  as separate variables.

What are keywords?
- Keywords are reserved words of the language.
- They should not be used for any other purpose other than there intended ones.
- Note 'main' is not a keyword.
- Refer 'summary of c++ keywords.pdf' for a list of keywords supported by C++ 03 through C++ 20.

What are white space characters?
- Space, tab and new line are called as white space characters.

What are camel case, pascal case and snake case?
- There are three casing styles prevalent in computing industry viz. camel case, pascal case and snake case.
- Ex of camel case: memoryFile, toolBar, tabManager
- Ex of pascal case: MemoryFile, ToolBar, TabManager
- Ex of snake case: memory_file, tool_bar, tab_manager
*/
