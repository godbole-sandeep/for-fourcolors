#define T int

int main() {
	signed T a = 123;
	unsigned T b = 123U;
	long T c = 123L;
	short T d = 123;

	unsigned long T e = 123UL;
	unsigned short T f = 123;
	signed long T g = 123;
	signed short T h = 123;
	
	return 0;
}

/*
What are type modifiers?
- Type modifiers are keywords that alter the properties of data types,
  affecting their size, range, or behavior.
- The type modifiers are 'signed', 'unsigned', 'long','short'.
- The 'signed' modifier specifies that a variable can represent both positive and negative values.
  It is often used with integer data types.
- The 'unsigned' modifier specifies that a variable can represent only non-negative values.
  It is often used with integer data types.
- The 'long' modifier increases the size of a data type, typically to twice the size of the standard data type.
- The 'short' modifier reduces the size of a data type, typically to half the size of the standard data type.
- Remember not all modifiers work with every type.

Which type modifiers go with 'int'?
- All type modifiers go with 'int'.
- By default int is signed.
- In MSVC++, 'int' and 'long int' have the same size of 4 bytes.
- In MSVC++, the 'short int' has a size of 2 bytes.
- The table below summarizes usages of 'signed', 'unsigned', 'long', 'short' with 'int'.
  +----------+----------+----------+
  |          |          |          |
  +----------+----------+          |
  | unsigned |   long   |----------+
  +----------+----------+		   |
  |  signed  |  short   |   int    |
  +----------+----------+----------+

Which type modifiers go with 'char'?
- Only 'signed' and 'unsigned' type modifiers go with 'char'.
- The table below summarizes usages of 'signed', 'unsigned' with 'char'.
  +----------+----------+
  |          |          |
  +----------+          |
  | unsigned |   char   |
  +----------+          |
  |  signed  |          |
  +----------+----------+

Which type modifiers go with 'wchar_t'?
- None of the type modifiers go with 'wchar_t'.

Which type modifiers go with 'float'?
- Only 'long' type modifier goes with 'float'.
- The table below summarizes usages of 'long' with 'float'.
  +----------+----------+
  |          |          |
  +----------+  float   |
  |   long   |          |
  +----------+----------+

Which type modifiers go with 'double'?
- Only 'long' type modifier goes with 'double'.
- In MSVC++, 'double' and 'long double' have the same size of 8 bytes.
- The table below summarizes usages of 'long' with 'double'.
  +----------+----------+
  |          |          |
  +----------+  double  |
  |   long   |          |
  +----------+----------+

Which type modifiers go with 'bool'?
- None of the type modifiers go with 'bool'.
*/