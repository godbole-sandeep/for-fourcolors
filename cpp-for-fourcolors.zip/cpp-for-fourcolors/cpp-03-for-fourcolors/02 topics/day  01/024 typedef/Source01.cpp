#include <iostream>

// Define uint as an alias for unsigned int
typedef unsigned int uint;

// Define ulong as an alias for unsigned long
typedef unsigned long ulong;

int main() {
    return 0;
}

/*
What does typedef do?
- 'typedef' is used to create type aliases, allowing programmers
  to define alternative names for existing data types.
*/