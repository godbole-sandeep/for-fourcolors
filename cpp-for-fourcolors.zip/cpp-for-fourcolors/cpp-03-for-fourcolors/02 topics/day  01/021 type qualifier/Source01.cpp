
/*
What does 'const' do?
- The const type qualifier in C++ is used to create constant variables,
  which cannot be modified after initialization.
- Using const allows us to create variables whose values are known at
  compile-time and remain constant throughout the program's execution.
*/