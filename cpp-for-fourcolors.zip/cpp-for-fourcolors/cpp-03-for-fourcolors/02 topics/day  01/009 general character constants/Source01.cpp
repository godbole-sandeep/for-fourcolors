
/*
What are character constants?
- Character constants are fixed values that represent individual characters.
- A character constant is encapsulated in single quotes. For example 'A', '6', 'z' etc.
- A character constant represents a single character.
- If you want to represent a sequence of characters, you would use a string literal (enclosed in double
  quotes) instead of a character constant.

What is a character set?
- A character set is a defined as collection of characters.

What is character encoding?
- A character encoding is a system that assigns a unique numeric code to each character in a character set.

What are narrow characters?
- Narrow characters typically refer to characters in the basic character set,
  commonly encoded using ASCII or a similar encoding.
- In C++, narrow characters are of type 'char'.
- Examples of narrow character constants include 'A', '1', '$', etc.
- Narrow characters are suitable for representing characters from the basic character set
  and are commonly used in many C++ programs.

What are wide characters?
- Wide characters are particularly important when working with internationalization and
  need to handle characters from different languages.
- In C++, wide characters are of type 'wchar_t'.
- Wide character constants are written with an 'L' prefix, and they are enclosed in single quotes.
  For example, L'A', L'1', L'$', etc.
- Wide characters can represent a broader range of characters, including those outside the basic
  character set, and are important for handling multibyte character encodings like UTF-16 or UTF-32.

How much memory do the data types 'char' and 'wchar_t' require?
- The 'char' data type typically requires 1 byte (8 bits) of memory.
- The 'wchar_t' data type typically requires 2 or 4 bytes of memory,
  depending on the platform and compiler settings.

What exactly does each bit in a 8-bit 'char' represent?
- The following table summarizes the meaning of each bit in a 8-bit 'char'.
  +----------+-----------------------+
  | Bits     | Meaning               |
  +----------+-----------------------+
  | 0 to 6   | Character code/Number |
  +----------+-----------------------+
  |   7      | Sign bit				 |
  +----------+-----------------------+
- A sign bit of 0 indicates a positive real number, while 1 indicates a negative real number.

What exactly does each bit in a 16-bit 'wchar_t' represent?
- All 16-bits are used for storing character code.
  +----------+----------------+
  | Bits     | Meaning        |
  +----------+----------------+
  | 0 to 15  | Character code |
  +----------+----------------+
*/