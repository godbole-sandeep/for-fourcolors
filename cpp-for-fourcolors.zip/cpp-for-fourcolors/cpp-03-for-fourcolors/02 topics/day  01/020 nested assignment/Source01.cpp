
/*
What is nested assignment?
- Nested assignment involves assigning a value to a variable,
  and then immediately using that variable to assign a value
  to another variable or the same variable again, possibly in
  a hierarchical or nested manner.
*/
