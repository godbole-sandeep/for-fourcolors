﻿
/*
What are floating point constants?
- Floating-point constants are real numbers with fractional components.
- These values are typically written with a decimal point or in scientific notation.

What is precision?
- Precision refers to the number of significant digits used to represent a real number.
- It determines the accuracy with which a floating-point number represents a value.
- 3.14159265358979323846 has higher precision than 3.141592 since it has more digits.
- In other words, 3.14159265358979323846 is closer to the actual value of π than 3.141592.
- There are two common measures of precision for floating-point numbers: Single Precision and Double Precision.
- Single precision floating-point constants, often referred to as 'float' constants.
- Double precision floating-point constants, often referred to as 'double' or 'long double' constants.

How are floating point constants classified?
- Floating-point constants are classified as float, double, or long double based on the suffix used or
  not used thereof.
- When a number is not followed by a special letter, it is referred to as 'double'. For example 3.141592, 9.81 etc.
- If a number is suffixed by 'f' or 'F', it is considered as 'float'. For example 3.141592f, 9.81F etc.
- If a number is suffixed by 'l' or 'L', it is considered as 'long double'. For example 3.141592l, 9.81L etc.

What are the types of 3.14, 3.0e8f, 2.5, 9.81L?
- 3.14 is a floating-point constant of type double.
- 3.0e8f is a floating-point constant, written in scientific notation and is of type float.
- 2.5f is a floating-point constant of type float.
- 9.81L is a floating-point constant of type long double.

How much memory do the data types 'float', 'double' and 'long double' require?
- Floating-point constants in C++ are typically represented in memory using the IEEE 754 standard.
- The standard defines a size of 4 bytes (32 bits) for 'float' data type and 8 bytes (64 bits) for
  'double' and 'long double'.

What exactly does each bit in a 32-bit 'float' represent?
- The following table summarizes the meaning of each bit in a 32-bit 'float'.
  +----------+----------------+
  | Bits     | Meaning        |
  +----------+----------------+
  | 0 to 22  | Magnitude bits |
  +----------+----------------+
  | 23 to 30 | Exponent bits  |
  +----------+----------------+
  |   31     | Sign bit       |
  +----------+----------------+
- A sign bit of 0 indicates a positive real number, while 1 indicates a negative real number.

What exactly does each bit in a 64-bit 'double' or 'long double' represent?
- The following table summarizes the meaning of each bit in a 32-bit 'float'.
  +----------+----------------+
  | Bits     | Meaning        |
  +----------+----------------+
  | 0 to 51  | Magnitude bits |
  +----------+----------------+
  | 52 to 62 | Exponent bits  |
  +----------+----------------+
  |    63    | Sign bit       |
  +----------+----------------+
- A sign bit of 0 indicates a positive real number, while 1 indicates a negative real number.
*/