
/*
What exactly is the 'static_cast' operator used for?
- 'static_cast' is an explicit type casting operator.
- It is used for explicit narrowing conversions, with
  the programmer aware of potential data loss.
*/