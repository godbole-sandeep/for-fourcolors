
/*
What is the type of floating point constant 10.0?
- It is 'double'.

What is the type of the variable 'doubleValue'?
- It is 'double'.

Does assigning 10.0 to 'doubleValue' need any type casting or conversion?
- No. Since 10.0 and 'doubleValue' have the same type as 'double',
  no type conversion is necessary during initialization.

What is the type of the variable 'intValue'?
- It is 'int'.

Does assigning 'doubleValue' to 'intValue' need any type casting or conversion?
- Yes. Since doubleValue is of type double and intValue is of type int,
  a type casting or conversion from double to int is required.
- This kind of casting is referred to as 'narrowing casting'.
- 'Narrow casting' occurs when a data type having a higher range or precision
  is assigned to a data type with a lower range or precision.
- This conversion may result in loss of information or truncation of data.
- The compiler notifies the programmer of the narrowing conversion by issuing a warning or an error.
- The warning or error can be resolved by explicitly casting using the'static_cast' operator.
*/