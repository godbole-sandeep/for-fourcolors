
/*
Can any function serve as an entry point function?
- According to C++ standards, except for'main', no other function can be used as
  an entry point function in a hosted environment.
- If we do not mention entry point function as expected in the project, we get linking error as below:
  error LNK2019: unresolved external symbol _main referenced in function "int __cdecl invoke_main(void)" (?invoke_main@@YAHXZ)
*/