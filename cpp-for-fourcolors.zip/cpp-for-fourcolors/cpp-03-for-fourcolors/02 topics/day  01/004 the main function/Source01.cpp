
/*
What is main?
- 'main' is a function.
- 'main' is also an entry point function of a console application.
- 'WinMain' is an entry point function of a Windows application.
- The entry point function is where the program execution begins.
- C++ is a case-sensitive language, the entry point function for a console application must be
  named 'main' in lowercase. Variations such as 'Main', 'MAIN', or 'mAIN' are not valid.

How many entry points an application can have?
- One and only one.

How many exit points an application can have?
- One or many.

- What happens if the entry point function is not specified in the project?
  It results in linking error.

What does 'return 0' do?
- When the return statement is executed in main, the control is returned to the operating system.
- The value mentioned in the return statement (0 in this case) is returned to the operating system.
- The value returned to the operating system is called as exit code of the program.
- The programming convention says that if program exits with a value of 0, it means it was
  successfully executed. If the exit code is not 0, it is recommended that you consult the
  documentation to determine what it means.

What is the significance of semicolon(;)?
- It acts as a statement terminator.
- It indicates the end of a statement.
- Each executable statement is terminated with a semicolon.
*/