
/*
Why do we need numbers?
- We need number to represent count.

What is numbering or numeral system?
- A numbering system is a system of symbols used to represent numbers.

Which numbering system do we use in daily life?
- Decimal

Which numbering systems are commonly used in the computing industry?
- Decimal
- Binary
- Octal
- Hexadecimal

What symbols decimal, binary, octal and hexadecimal numbering systems are made up of?
	Value          Decimal          Binary          Octal          Hexadecimal
	--------------------------------------------------------------------------
	Zero			  0				   0			  0					0
	One				  1				   1			  1					1
	Two				  2								  2					2
	Three			  3								  3					3
	Four			  4								  4					4
	Five			  5								  5					5
	Six				  6								  6					6
	Seven			  7								  7					7
	Eight			  8													8
	Nine			  9													9
	Ten																	A
	Eleven																B
	Twelve																C
	Thirteen															D
	Fourteen															E
	Fifteen																F

Given a number 1, how does a computer determine which numeral system it belongs to?
- 1: A number without any prefix is assumed to belong to the decimal numbering system.
- 0b1: A number with a 0b prefix is assumed to belong to the binary numbering system.
- 01: A number with a 0 prefix is assumed to belong to the octal numbering system.
- 0x1: A number with a 0x prefix is assumed to belong to the hexadecimal numbering system.

Which numbering system do we use in computer systems?
- Binary

How is a number like 108 represented in binary?
- Using place value technique.

What are integer constants?
- Integer constants in C++ are fixed values that represent whole numbers (integers).

What are the different formats in which integer constants can be written?
- Integer constants can be written in different formats, such as decimal, octal, or hexadecimal.
- 26 is a decimal integer constant (no prefix)
- 026 is an octal integer constant (starts with '0')
- 0x26 is a hexadecimal integer constant (starts with '0x')

How are integer constants classified?
- Integer constants are classified as 'int' type.

How much memory does a 'int' data type require?
- On most modern systems, 'int' requires 4 bytes (32 bits) of memory.

How can I compute the size of a 'int' programmatically?
- Use sizeof() operator to compute size of any data type.

What exactly does each bit in a 32-bit 'int' represent?
- The following table summarizes the meaning of each bit in a 32-bit 'int'.
  +---------+----------------+
  | Bits    | Meaning        |
  +---------+----------------+
  | 0 to 30 | Magnitude bits |
  +---------+----------------+
  |   31    | Sign bit       |
  +---------+----------------+
- A sign bit of 0 indicates a positive integer, while 1 indicates a negative integer.
*/