int main() {
    return 0;
}

/*
What are bool constants?
- Bool constants are literals representing boolean values.
- A boolean value can either be 'true' or 'false'.
- The C++ language has two bool constants: 'true' and 'false'.
- Bool constants are commonly used in conditional statements, loops,
  and other situations where boolean values are required.

How are the boolean constants 'true' and 'false' classified?
- Boolean constants are classified as 'bool' type.

How much memory does a 'bool' data type require?
- The 'bool' data type typically requires 1 byte (8 bits) of memory.

What exactly does each bit in a 8-bit 'bool' represent?
- All 8-bits are used for storing boolean value.
- A value of 0 indicates 'false', whereas +ve or -ve indicate 'true'.
*/