
/*
What are string constants/literals?
- String constants in C++ are sequences of characters enclosed in double quotes (").
- In this example, "Hello, World!" is a string constant.
- In C++, string constants are null-terminated, meaning  that a null character ('\0')
  is automatically added at the end to mark the end of the string.
- String constants are essential for working with textual data in C++ programs.

How are string constants classified?
- String constants are classified as a C-style character array of either 'wchar_t' or
  'char' type based on the prefix used or not used thereof.
- When a string literal is not prefixed by a special letter, it is referred to as 
  C-style array of 'char'. For example "Hello, World!". Such string is called as
  narrow character string.
- If a string constant is prefixed by 'L', it is considered as C-style array of 'wchar_t'.
  For example L"Hello, World!". Such string is called as wide character string.

How much memory do narrow character string require?
- Narrow character strings typically require 1 byte of memory per character.
- Therefore, the memory required for a narrow character string can be calculated
  by multiplying the number of characters in the string by the size of each character, which is 1 byte,
  plus 1 byte for null character.
- Thus, "Hello, World!" would need 14 bytes of memory space.

How much memory do wide character string require?
- Wide character strings typically require 2 bytes of memory per character.
- Therefore, the memory required for a wide character string can be calculated
  by multiplying the number of characters in the string by the size of each character, which is 2 bytes,
  plus 2 bytes for null character.
- Thus, L"Hello, World!" would need 28 bytes of memory space.
*/