#include <iostream>

int main() {
    std::cout << "HelloWorld";
    std::cout << "This is a backslash: ";
    return 0;
}

/*
What are escape sequence character constants?
- Escape sequences represent non-printable or special characters.
- These sequences start with a backslash (\), followed by a specific character or
  combination of characters.
- Here's a quick list of some common escape sequences and their meanings:
  \': Single quote
  \": Double quote
  \\: Backslash
  \n: Newline (line feed)
  \t: Tab
  \b: Backspace
  \r: Carriage return
  \f: Form feed
  \a: Alert (bell)
  \v: Vertical tab
  \0: Null character
  \?: Question mark
*/