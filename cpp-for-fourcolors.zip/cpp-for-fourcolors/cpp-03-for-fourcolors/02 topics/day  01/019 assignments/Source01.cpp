
/*
What is an assignment?
- In programming, an assignment refers to the process of storing a value in a variable.
- It may also be thought of as replacing a variable's current value with a new one.
- It involves using the assignment operator (=) to assign a value to a variable.
- The value on the right side of the assignment operator is evaluated,
  and then stored in the variable on the left side.
*/
