
/*
What does '#' in the #include statement imply?
- It implies presence of preprocessor directive.

What is the #include statement?
- '#include' is called, the preprocessor directive.

Is '#include' the only preprocessor directive?
- No, '#include' is not the only preprocessor directive.
- There are several other preprocessor directives such as:
  #define, #undef, #if, #elif, #else, #endif, #error, #line etc.

What does the '#include' statement do?
- It includes the contents of the file mentioned in angle brackets (<>) next to it
  in the current file.
- For example, in the present scenario, it includes contents of 'iostream' file in
  the current file, which is 'Source01.cpp'.

What is 'iostream'?
- 'iostream' essentially is a file. More precisely, it is a 'header file'.

Is 'iostream' the only header file?
- No, there are several other header files.
- For example, malloc.h, string, cmath etc.
- Note there are many more header files.
- We will see them as we advance in the course.

Why did we include the 'iostream' header file in the present scenario?
- We included the 'iostream' header file because we are utilizing 'std::cout',
  the output stream object, in the current code.
- The 'std::cout' object has been defined in 'iostream' header file.

What would happen if we did not include the 'iostream' header file,
yet continued to use the 'std::cout' object?
- You would encounter compilation errors.
- This is because 'std::cout' is part of the 'iostream' library, and without including the header file,
  the compiler wouldn't know how to interpret the 'std::cout' object. 
- Therefore, including the 'iostream' header file is essential for using 'std::cout' and
  other functionalities provided by the 'iostream' library in your C++ code.
*/