
/*
What is the type of integer constant 10?
- It is 'int'.

What is the type of the variable 'intValue'?
- It is 'int'.

Does assigning integer constant 10 to 'intValue' need any type casting or conversion?
- No. The variable 'intValue' and the integer constant 10 have the same 'int' type,
  eliminating the requirement for type casting or conversion.
- The constant integer 10 is assigned to the 'intValue' variable directly.
*/