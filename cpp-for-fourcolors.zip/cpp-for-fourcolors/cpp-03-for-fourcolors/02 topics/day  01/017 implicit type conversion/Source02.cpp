
/*
What is the type of the variable 'intValue'?
- It is 'int'.

What is the type of the variable 'doubleValue'?
- It is 'double'.

Does assigning 'intValue' to 'doubleValue' need any type casting or conversion?
- Yes. Since doubleValue is of type double and intValue is of type int,
  a type casting or conversion from int to double is required.
- This type of type casting is known as 'implicit casting'.

What is 'implicit casting'?
- Implicit casting is the conversion of smaller data types (e.g., int) to
  larger data types (e.g., double).
- This conversion is referred to as a widening conversion since the destination data type may
  represent the whole range of values of the source data type without losing information.
*/