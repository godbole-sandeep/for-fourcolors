#include <iostream>

int main() {
	int a = 0;
	std::cout << "Enter first number: ";
	std::cin >> a;

	int b = 0;
	std::cout << "Enter second number: ";
	std::cin >> b;

	int c = Add(a, b);

	std::cout << "Sum of first and second number is " << c << std::endl;
	
	return 0;
}

/*
What does a header file contain?
- A header file typically contains:
  1. Function Declarations.
  2. Macros and Constants.
  3. Include Guards.

Why are header file names sometimes surrounded by double quotes and
other times by angle brackets?
- A header file is surrounded by double quotes when it needs to be located
  in the same directory as the source file or in a custom directory specified
  by the user.
- A header file is surrounded by angle brackets when it is to be located in
  the standard include directories.
*/