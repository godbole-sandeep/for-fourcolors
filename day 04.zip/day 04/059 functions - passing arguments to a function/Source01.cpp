#include <iostream>

int main() {
	int a = 0;
	std::cout << "Enter first number: ";
	std::cin >> a;

	int b = 0;
	std::cout << "Enter second number: ";
	std::cin >> b;

	return 0;
}

/*
What are parameters?
- Parameters are variables listed as part of a function's definition.
- They act as placeholders for the values that will be passed to the
  function when it is called, allowing the function to operate on
  different data each time it is executed.

What are the types of the parameters?
- Formal Parameters. And,
- Actual Parameters also known as Arguments.

What are formal parameters?
- These are the parameters defined in the function's declaration or definition.
- For example, the variables 'u' and 'v' defined in the 'Add' function definition are
  known as formal parameters.
- The data type for each formal parameter is required to be specified.

What are actual parameters or arguments?
- These are the values or variables provided to the function when it is called.
- For example, the variables 'a' and 'b' supplied in the 'Add' function call in
  'main' are considered actual parameters or arguments.
*/
