#include <iostream>

int main() {
	int a = 0;
	std::cout << "Enter first number: ";
	std::cin >> a;

	int b = 0;
	std::cout << "Enter second number: ";
	std::cin >> b;

	int c = 0;
	c = a + b;

	std::cout << "Sum of first and second number is " << c << std::endl;

	return 0;
}

/*
What does the above program do?
- The program is performing a basic addition of two integers entered by the user. 
*/