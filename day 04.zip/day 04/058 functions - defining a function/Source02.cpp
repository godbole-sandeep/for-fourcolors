#include <iostream>

int main() {
	Add(); /* function call */
	Add();
	Add();
	return 0;
}

/*
What is a function?
- A function is a self-contained block of code designed to perform
  a specific task or operation.
- Functions are fundamental components of structured and modular programming.
- Both 'main' and 'Add' are known as functions.

What enables code reusability in programming?
- Functions allow code reusability.

What is caller?
- The caller is the function that calls another function.
- For example, in the code above,'main' is the caller for the 'Add' function.

What is callee?
- The callee is the function that is being called.
- For example, in the code above, 'Add' is the callee.

How to debug a function?
- Use the step-in, step-over, and step-out features to execute code
  line by line and observe the flow of control.

What is step-into?
- Executes the next line of code.
- If the next line is a function call, the debugger enters
  the called function and pauses at the first line inside it.

What is step-over?
- Executes the next line of code.
- If the next line is a function call, the debugger executes the
  entire function and pauses at the next line in the current function.

What is step-out?
- Continues execution until the current function returns, then pauses at the line
  immediately after the function call in the calling function.
*/
