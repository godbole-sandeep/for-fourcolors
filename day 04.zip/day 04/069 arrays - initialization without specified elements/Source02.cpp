int main() {
	// Declaration and initialization of an array of integers
	return 0;
}

/*
What is wrong with the code above?
- In C++, the size of an array must be known at compile-time, either explicitly
  specified or deduced from the number of initialization values.
- The code is wrong since it violates the rule mentioned above.
*/