#include <iostream>

int main() {
	int a = 0;
	std::cout << "Enter first number: ";
	std::cin >>a;

	int b = 0;
	std::cout << "Enter second number: ";
	std::cin >> b;

	Add(a, b);

	std::cout << "Sum of first and second number is " << c << std::endl;

	return 0;
}

/*
What is return type?
- Functions can return a value after execution.
- The return type specifies the type of value the function returns.
*/