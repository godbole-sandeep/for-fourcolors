int main() {
	return 0;
}

/*
What is an array?
- An array is essentially a collection of elements, all of which have the same data type.

What is the general syntax for defining an array?
- The general syntax for defining an array is
  datatype array-name[array_size1][array_size2][array_size3]...[array_sizeN]
  where
  data_type specifies the type of data that the array will hold (e.g., int, double, char, etc.).
  array_name is the identifier used to refer to the array.
  array_size1, array_size2, array_size3,...,array_sizeN indicates the number of elements the array can hold.
  It must be a non-negative integer.

What is a single-dimensional array?
- An array defined with 'data_type array_name[array_size];' syntax is known as single-dimensional array.
  For example: int numbers[5];

What is a double-dimensional array?
- An array defined with 'data_type array_name[array_size1][array_size2];' syntax is known as double-dimensional array.
  For example: int matrix[3][4];

What is a N-dimensional array?
- An array defined with 'datatype array-name[array_size1][array_size2][array_size3]...[array_sizeN];'
  syntax is known as N-dimensional array.

Which dimensions of arrays are most commonly used?
- Single-dimension and double-dimensiona arrays are most commonly used.

Can array_size be changed at runtime?
- Arrays have a fixed size, meaning you specify the number of elements it can hold
  when you declare it. Once the size is defined, it cannot be changed during runtime.

Are array elements spread down continuously or discretely as memory is available?
- Elements in an array are stored in contiguous memory locations.

What is an array's biggest single strong point?
- The biggest advantage of an array lies in accessing its first and last elements.
- Accessing the first and last elements takes the same amount of time.
*/