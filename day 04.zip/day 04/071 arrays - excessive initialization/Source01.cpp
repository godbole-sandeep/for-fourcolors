int main() {
	// Declaration and initialization of an array of integers
	return 0;
}

/*
What is excessive array initialization?
- Excessive initialization occurs when you provide more initialization values than the declared size of the array.
- This results in a compilation error because there are not enough elements in the array to hold all the provided values.
*/