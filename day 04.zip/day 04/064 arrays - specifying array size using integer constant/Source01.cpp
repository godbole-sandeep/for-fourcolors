int main() {
	int numbers[5];
	return 0;
}

/*
What is the key point to note in the program above?.
- You can use a literal constant to specify the array size.
*/