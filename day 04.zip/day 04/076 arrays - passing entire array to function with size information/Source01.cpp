#include <iostream>

int main() {
    int numbers[5] = { 1, 2, 3, 4, 5 };
    return 0;
}

/*
What are the key points to note in the program above?
- The 'ModifyArray' function iterates through the array and increments each element.
- The Print function outputs the modified values.
- The main function orchestrates these operations by first calling ModifyArray to
  alter the array and then calling Print to display the resulting values.
*/