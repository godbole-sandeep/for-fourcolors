int main() {
	int numbers[5] = { 10, 20, 30, 40, 50 };
	return 0;
}

/*
How to access element of an array?
- You access array elements using square brackets ([]) notation with the index of the element you want to access.
- Here's the syntax: array_name[index]  where,
  array_name is the name of the array.
  index is the zero-based index of the element you want to access.
*/