#include <iostream>

int main() {
    // Single-dimensional array of integers
    int numbers[5] = { 10, 20, 30, 40, 50 };

    // Accessing and printing elements of the single-dimensional array
    std::cout << "Single-dimensional array:" << std::endl;
    for (int i = 0; i < 5; ++i) {
        std::cout << "Element " << i << ": " << numbers[i] << std::endl;
    }

    return 0;
}

/*
What is the key point to note in the program above?
- The program prints the values stored in the array elements.
*/