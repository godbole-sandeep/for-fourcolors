#include <iostream>

int main() {
    int numbers[5]; // Declare an array of integers

    // Calculate the size of the array
    size_t size_of_array = sizeof(numbers);

    std::cout << "Size of the array in bytes: " << size_of_array << std::endl;

    // Calculate the size of an individual element in the array
    size_t size_of_element = sizeof(numbers[0]);

    std::cout << "Size of each element in the array in bytes: " << size_of_element << std::endl;

    // Calculate the number of elements in the array
    size_t num_elements = size_of_array / size_of_element;

    std::cout << "Number of elements in the array: " << num_elements << std::endl;

    return 0;
}

/*
How to calculate the size of an array in memory?
- You can calculate the size of an array in memory using the sizeof operator.
- The sizeof operator returns the size of its operand in bytes.
- When applied to an array, it gives the total size of the array in memory.
*/