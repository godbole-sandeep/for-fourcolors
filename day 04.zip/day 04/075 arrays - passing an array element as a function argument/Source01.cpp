#include <iostream>

int main() {
	int a[] = { 1, 2, 3, 4, 5, 6, 7 };
	return 0;
}

/*
Is sizeof() a function or something else?
- It is not a function.
- It is an operator.

What can be passed as an argument to sizeof?
- Either a variable or a type can be passed to sizeof.

What does sizeof return?
- sizeof returns the size of a variable or type in bytes.
- If an array is passed to `sizeof`, it returns the total size of
  the array in bytes.
*/