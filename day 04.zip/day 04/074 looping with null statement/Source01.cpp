int main() {
	const int arraySize = 5;
	int a[arraySize] = { 0 };
	return 0;
}

/*
What is a null statement?
- A null statement in programming refers to a statement that consists of a single semicolon (;)
  and performs no operation.
- It is also known as an empty statement.

Where could it be used?
- The null statement is often used in places where the syntax requires a statement but no action
  needs to be performed.
- It's particularly useful in control structures like loops.
*/