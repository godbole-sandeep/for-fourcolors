#include <iostream>

int main() {
	int a = 0;
	std::cout << "Enter first number: ";
	std::cin >> a;

	int b = 0;
	std::cout << "Enter second number: ";
	std::cin >> b;

	int c = Add(a, b);

	std::cout << "Sum of first and second number is " << c << std::endl;

	return 0;
}

int Add(int u, int v) {
	int w = 0;
	w = u + v;
	return w;
}

/*
What are the key points to note in the program above?
- The program is the same as the one mentioned in the preceding file.
- The only difference is that the function is moved to the end of the file.

Does this difference affect the compilation behavior of this program?
- Yes, this change results in a compilation error.

Why is the program giving a compilation error?
- The C++ compiler processes the program from the top of the file to the bottom.
- During this process, the compiler encounters a call to the Add function at line 12.
- Since the Add function has not been declared or defined earlier in the file,
  the compiler treats it as an unknown symbol.
- As a result, the compiler generates an error.

Why didn't the previous program give a compilation error?
- In the previous program, the Add function was placed at the beginning of the file.
- Since the C++ compiler processes the program from top to bottom,
  it encounters the Add function definition first.
- This definition introduces the compiler to the Add symbol, making it a known symbol.
- Consequently, when the compiler encounters the call to the Add function later in the code,
  it recognizes the symbol and does not produce an error.

So, what is the solution to the existing program?
- Declare the function at the beginning of the file.
- This ensures that the compiler is aware of the function's existence
  before encountering its usage later in the code.
- The next source file, 'Source03.cpp' is illustrating the same.
*/