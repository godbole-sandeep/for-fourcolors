#include <iostream>

int main() {
	int a = 0;
	std::cout << "Enter first number: ";
	std::cin >> a;

	int b = 0;
	std::cout << "Enter second number: ";
	std::cin >> b;

	int c = Add(a, b);

	std::cout << "Sum of first and second number is " << c << std::endl;

	return 0;
}

int Add(int u, int v) {
	int w = 0;
	w = u + v;
	return w;
}

/*
What are the key points to note in the program above?
- Take note of the function declaration at the beginning (line 3) of the file.
- The definition of 'Add' remains at the end of the file.

What is the difference between a function declaration and a function definition?
- A function declaration provides the compiler with information about the function's
  name, return type, and parameters without offering the actual implementation.
- A function definition, on the other hand, provides the actual implementation of the function,
  including the body where the function's operations are specified.

Can a function declaration and definition be used interchangeably?
- A function declaration includes only the function signature, not the body.
- A function definition includes both the function signature and the body.
- Therefore While a function definition can replace a function declaration,
  a function declaration cannot replace a function definition.
- If a function definition is used to replace a function declaration, the order
  of appearance of the function definition and function call matters to the compiler.
  The function definition should appear before the function call.

What does the compiler require: a function declaration or a function definition?
- The compiler needs a function declaration to understand the function�s signature.
- The compiler does not need the function definition to perform this task.

What does the linker require: a function declaration or a function definition?
- The linker needs the function definition.

What is the requirement of linker?

- Function definition can replace function declaration but vice versa is not true.
- If function definition is to replace function declaration, then order of
  appearance of function definition and function call matters to compiler.
  Function definition should appear before function call.
*/
