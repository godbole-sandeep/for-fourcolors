#include <iostream>

int Add(int u, int v) {
	int w = 0;
	w = u + v;
	return w;
}

int main() {
	int a = 0;
	std::cout << "Enter first number: ";
	std::cin >> a;

	int b = 0;
	std::cout << "Enter second number: ";
	std::cin >> b;

	int c = Add(a, b);

	std::cout << "Sum of first and second number is " << c << std::endl;

	return 0;
}

/*
What are the key points to note in the program above?
- The 'Add' function is written at the beginning of the file.
- Above program builds successfully.
*/