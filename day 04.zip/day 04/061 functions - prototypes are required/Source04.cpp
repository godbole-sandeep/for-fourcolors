double RectArea(int, int, int, int);

int main() {
	double area;
	return 0;
}

/*
Can formal parameter names be omitted in a function declaration?
- Yes, formal parameter names can be omitted in a function declaration.
- However, omitting these names makes it difficult for other developers
  to understand what arguments are expected when calling the function.
- For example, in the RectArea function declaration, if the formal parameter
  names are omitted, developers may not know whether to pass arguments such
  as x1, y1, x2, y2 or x, y, width, height, or something else entirely.
- Therefore, retaining formal parameter names in a function declaration
  is considered good coding practice. 
*/