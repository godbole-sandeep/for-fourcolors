int main() {
	return 0;
}

/*
What is the key point to note in the program above?
- You can use a constant variable to specify the array size.
*/