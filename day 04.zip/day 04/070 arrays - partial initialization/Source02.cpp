int main() {
	// Declaration and initialization of an array of integers
	return 0;
}

/*
What does the above syntax accomplish?
- This is a special form of parital initialization.
- The first element of an array is set to zero because the initializer specified is 0.
- The rest of the elements are automatically set to zero because appropriate number of
  initializers is not provided.
- In short, this is a quick syntax for setting all elements of an array to 0.
*/