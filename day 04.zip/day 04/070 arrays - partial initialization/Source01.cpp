int main() {
	// Declaration and initialization of an array of integers
	return 0;
}

/*
What is partial array initialization?
- Partial initialization refers to initializing only a portion of the elements
  in an array while leaving the remaining elements uninitialized.
- In C++, when you initialize an array with fewer elements than its declared
  size, the compiler automatically initializes the remaining elements to zero
  (or their corresponding default values if the array contains non-fundamental
  types).
*/