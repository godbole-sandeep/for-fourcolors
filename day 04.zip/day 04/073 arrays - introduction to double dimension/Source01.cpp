#include <iostream>

int main() {
    return 0;
}

/*
What are the key points to note in the program above?
- The program illustrates:
  1. How to define and initialize a two-dimensional array.
  2. How to access and print the values stored in the array elements.
*/