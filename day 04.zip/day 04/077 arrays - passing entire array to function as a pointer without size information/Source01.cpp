#include <iostream>

int main() {
	int arr[] = { 1, 2, 3, 4, 5, -1 }; // Sentinel value -1 marks the end of the array
	return 0;
}

/*
What are the key points to note in the program above?
- A sentinel value is a special value that marks the end of an array.
- In the program mentioned above, '-1' serves as a sentinel value.
- The function that processes an array searches for the sentinel value and
  stops processing once found.
- Thus, using a sentinel value helps eliminate the need to pass the array
  size as an additional argument.
- However, it requires ensuring that the sentinel value is included in one
  of the array elements.
*/