
/*
What is a pure virtual function?
- A pure virtual function is a function in a base class that is declared but not defined.
- The PerformAction function of the Base class is an example of a pure virtual or abstract function.
- When the implementation of a base class action is unknown or varies in derived classes,
  it is declared as a pure virtual or abstract function.
*/