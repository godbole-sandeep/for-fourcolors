
/*
What is an abstract class?
- A class that contains one or more pure virtual or abstract functions is known as an abstract class.
- Since the Base class has PerformAction as an abstract function, it is considered an abstract class.
- An abstract class cannot be instantiated.

What is a concrete class?
- A class that can be instantiated is called a concrete class.
*/