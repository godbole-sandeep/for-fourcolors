
/*
Can a pointer or reference be defined for an abstract class?
- An abstract class object cannot be defined, but its pointer and reference can be.
*/