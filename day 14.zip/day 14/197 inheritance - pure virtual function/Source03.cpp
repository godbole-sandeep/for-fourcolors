
/*
What if a pure virtual or abstract function of the base class is not
implemented in the derived class?
- In that case, the derived class also becomes an abstract class.
*/
