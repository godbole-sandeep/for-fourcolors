
/*
How do you initialize data members of base and derived classes?
- Data members of base and derived classes can also be initialized
  in the body of the respective constructors.
*/