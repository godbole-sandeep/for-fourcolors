#include <iostream>

class Base {
public:
	Base() : m_baseData(0) {}
private:
	int m_baseData;
};

class Derived : public Base {
public:
	Derived() : m_derivedData(0) {}
private:
	int m_derivedData;
};

int main() {
	Derived derivedObject;
	return 0;
}

/*
How do you initialize data members of base and derived classes?
- Data members of base and derived classes can be initialized using the
  initializer list.
*/