
/*
What is downcasting?
- Downcasting refers to casting a pointer or reference of a base class type to
  a pointer or reference of a derived class type.
- Unlike upcasting, downcasting requires an explicit type cast.
- This is because the compiler cannot guarantee the validity of such a conversion at compile-time.
- Use dynamic_cast operator to do downcasting.
- The base class must be polymorphic (should have presence of virtual function) for dynamic_cast to work.
- Adding virtual destructor to the base class makes base class polymorphic.
*/
