#include <cassert>
#include <cmath>
#include <iostream>

class Shape {
public:
	Shape(int x1, int y1, int x2, int y2)
		: m_x1(x1), m_y1(y1), m_x2(x2), m_y2(y2) {}
	virtual ~Shape() {}
public:
	int GetX1() const { return m_x1; }
	int GetY1() const { return m_y1; }
	int GetX2() const { return m_x2; }
	int GetY2() const { return m_y2; }
	void SetX1(int x) { m_x1 = x; }
	void SetY1(int y) { m_y1 = y; }
	void SetX2(int x) { m_x2 = x; }
	void SetY2(int y) { m_y2 = y; }
private:
	int m_x1;
	int m_y1;
	int m_x2;
	int m_y2;
};

class Circle : public Shape {
public:
	Circle(int x1, int y1, int x2, int y2)
		: Shape(x1, y1, x2, y2) {
		assert(x2 > x1 && y2 > y1);
		assert(std::abs(x2 - x1) == std::abs(y2 - y1));
	}
public:
	double GetRadius() const {
		return std::abs(GetX2() - GetX1());
	}
};

class Line : public Shape {
public:
	Line(int x1, int y1, int x2, int y2)
		: Shape(x1, y1, x2, y2) {
		assert(x2 > x1 && y2 > y1);
	}
public:
	double GetLength() const {
		int dx = GetX2() - GetX1();
		int dy = GetY2() - GetY1();
		return std::sqrt(dx * dx + dy * dy);
	}
};

void PrintShapeData(Shape* shapePtr) {
	if (dynamic_cast<Circle*>(shapePtr) != nullptr) {
		Circle* circlePtr = dynamic_cast<Circle*>(shapePtr); // downcasting
		std::cout << "Radius = " << circlePtr->GetRadius() << std::endl;
	}
	else if (dynamic_cast<Line*>(shapePtr) != nullptr) {
		Line* pline = dynamic_cast<Line*>(shapePtr); // downcasting
		std::cout << "Length = " << pline->GetLength() << std::endl;
	}
}

int main() {
	const size_t size = 2;
	Shape* shapePtr[size] = { new Circle(1, 1, 10, 10), new Line(1, 1, 10, 10) }; // upcasting

	for (size_t i = 0; i < size; i++) {
		PrintShapeData(shapePtr[i]);
	}

	delete shapePtr[0];
	delete shapePtr[1];

	return 0;
}

/*
- Members that are exclusive to the derived class are known as special members,
  such as the GetRadius of the Circle class and the GetLength of the Line class.
- The GetRadius of Circle class and the GetLength of Line class are known as Special Member Functions.
- Members that are exclusive to the base class are known as gneral members.
- To access exclusive members of a derived class, downcasting is essential.
*/