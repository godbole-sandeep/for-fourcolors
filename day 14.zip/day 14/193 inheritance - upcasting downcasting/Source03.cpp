
/*
- dynamic_cast is a casting operator used primarily for downcasting.
- It checks whether the conversion is valid at runtime.
- If the object being pointed to is actually of the derived type or any of its subclasses,
  the dynamic_cast succeeds and returns a pointer or reference of the derived class type.
- If the object isn't of the derived type, dynamic_cast returns a null pointer (for pointers)
  or throws a std::bad_cast exception (for references) if the cast fails.
*/