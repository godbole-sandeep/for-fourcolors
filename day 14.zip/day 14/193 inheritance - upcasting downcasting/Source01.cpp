
/*
What is upcasting?
- Upcasting refers to casting a pointer or reference of a derived class to
  a pointer or reference of its base class.
- Upcasting happens implicitly.
*/
