
/*
What is protected access?
- Protected access allows class members to be accessible to members of the class itself
  and derived classes.
- Protected access provides a level of access that is less restrictive than private but
  more restrictive than public.
- The following table summarizes the accessibility of private, protected, and public members
  for the class itself, derived classes, and non-member functions.
  -------------------------------------------------------------------------------
  Access			To Self			To Derived		To Non-member
  -------------------------------------------------------------------------------
  private			Available		Not-available	Not-available

  protected			Available		Available		Not-available

  public			Available		Available		Available

- It's not a good idea to declare data members of a base class as protected or public.
*/