
/*
What is the order of constructor and destructor execution in base and derived classes?
- When a Derived class object is instantiated, the Base class constructor is called first,
  followed by the Derived class constructor.
- Destructors always execute in the opposite order of constructors.
- Thus, when the same object goes out of scope, the destructor of the Derived class is
  executed first, followed by the destructor of the Base class.
*/