
/*
How do you call an overridden base class member function using an object of a derived class instance?
- The syntax base-class-name::member-function-name() can also be used with
  a derived class object to invoke the base class implementation of a member
  function instead of the derived class implementation.
- Note the call to Base::Print() within the main function using the expression
  derivedObject.Base::Print().
*/