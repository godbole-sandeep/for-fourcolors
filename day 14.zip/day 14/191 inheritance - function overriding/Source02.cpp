
/*
What is the key point to note in the program above?
- Call to 'Print' in 'Derived::Print' results in recursive function call.
*/