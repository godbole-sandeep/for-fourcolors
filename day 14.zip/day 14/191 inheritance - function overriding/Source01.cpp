
/*
What is function overriding?
- Function overriding allows a derived class to provide a
  specific implementation of a method that is already
  defined in its base class.
- The Derived::Print method is said to override Base::Print.
- This is known as function overriding.
- The derivedObject.Print() call invokes Derived::Print.
*/