

/*
Can there be a function in the derived class that attempts to access data members of both
the base class and the derived class?
- The Derived::Print function tries to access data members of both
  the Base and Derived classes.

Why does the program fail to compile?
- It fails to compile because the data member of the Base class is private
  and therefore inaccessible to Derived::Print.
- As a result, the code fails to build.

Are private data members of the base class inherited in the derived class?
- Yes, they are inherited in the derived class but are inaccessible to derived class members.
*/