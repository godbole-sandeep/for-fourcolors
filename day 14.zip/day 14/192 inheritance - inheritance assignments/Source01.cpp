
/*
- For all the explanations given below, it is assumed that 'Derived' class is 
  derived from 'Base' class. If they are independent, then the 3rd and 4th
  assignments will not work.
- Why is the first assignment, 'pbasePtr = &baseObject', working?
  Reason1: 'pbasePtr' is a pointer to the class 'Base', hence it should be allowed
           to point to an object of class 'Base'.
  Reason2: Using 'pbasePtr', we can call 'Base::PrintBaseData' at most. The requirement for 'Base::PrintBaseData' is 'm_baseData'. 
		   As 'baseObject' possesses 'm_baseData', this assignment is permissible.
- Why is the second assignment, 'pderivedPtr = &derivedObject', working?
  Reason1: 'pderivedPtr' is a pointer to the class 'Derived', hence it should be allowed
           to point to an object of class 'Derived'.
  Reason2: Using 'pderivedPtr', we can call 'Base::PrintBaseData' and 'Derived::PrintDerivedData' at most. The requirement for
           'Base::PrintBaseData' is 'm_baseData', and for 'Derived::PrintDerivedData' is 'm_derivedData'. As 'derivedObject' possesses both 'm_baseData' and
		   'm_derivedData', this assignment is valid.
- Why is the third assignment, 'pbasePtr = &derivedObject', working?
  Using 'pbasePtr, we can call 'Base::PrintBaseData' at most. The requirement for 'Base::PrintBaseData' is 'm_baseData'.
  Since 'derivedObject' possesses 'm_baseData', this assignment can be done.
- Why is the fourth assingment, 'pderivedPtr = &baseObject', failing?
  Using 'pderivedPtr', at most, we can call 'Base::PrintBaseData' and 'Derived::PrintDerivedData'. The requirement of
  'Base::PrintBaseData' is 'm_baseData' and that of 'Derived::PrintDerivedData' is 'm_derivedData'. Since 'baseObject' only has 'm_baseData' and
   lacks 'm_derivedData', this assignment cannot be done.
- In summary, a base class pointer can point to objects of both itself and its derived classes. 
- However, a derived class pointer can only point to its own objects; it cannot point to base class objects.
*/