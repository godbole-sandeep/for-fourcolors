#include <iostream>

class Base {
public:
    virtual void VirtualMethod1() {
        std::cout << "Base::VirtualMethod1()" << std::endl;
    }

    virtual void VirtualMethod2() {
        std::cout << "Base::VirtualMethod2()" << std::endl;
    }

    void NonVirtualMethod() {
        std::cout << "Base::NonVirtualMethod()" << std::endl;
    }
private:
    int m_baseData;
};

class Derived : public Base {
public:
    void VirtualMethod1() override {
        std::cout << "Derived::VirtualMethod1()" << std::endl;
    }
private:
    int m_derivedData;
};

int main() {
	Base baseObj, baseObj2;
	Derived derivedObj, derivedObj2;

	Base* basePtr = nullptr;

	basePtr = &baseObj;
	basePtr->VirtualMethod1();
	basePtr->VirtualMethod2();

	basePtr = &derivedObj;
	basePtr->VirtualMethod1();
	basePtr->VirtualMethod2();

    return 0;
}
