
/*
What are the key points to note in the program above?
- The object layout of a MyClass instance and a Base class instance is almost the same,
  except for the difference in the __vftpr.
- This difference is due to the presence of virtual member functions in the Base class.
- Note that __vfptr is per object, while the vtable is per class.
- The vtable contains addresses of virtual functions only.
- The vtable is stored in constant memory.
- A virtual member function is referred to as a polymorphic member function.
- A polymorphic member function facilitates polymorphism.
- A class that has one or more polymorphic member functions is known as a polymorphic class.
*/