
/*
What is dynamic binding?
- Binding that occurs at run time is known as dynamic binding.

Is static/dynamic binding class-wise or method-wise?
- Binding is method-wise. Thus, a class can have some methods that use
  static binding and others that use dynamic binding.

How do you indicate that a method should follow dynamic binding?
- This is indicated by prefixing the method signature with the
  virtual keyword. Virtual signals to the compiler that the method is
  expected to use dynamic binding.

What is a virtual function?
- A virtual function is a member function intended to be redefined in a
  derived class.

What changes occur when resolving a call to a virtual member function?
- The compiler is instructed not to prioritize the type of the pointer
  used to call the member function. Instead, it prioritizes the type
  of the object the pointer is pointing to.

Which functions can be virtual functions?
- Only non-static member functions of a class or struct can be virtual functions.

If a member function of a base class is marked as virtual, is it compulsory
to override this function in the derived class?
- No, it�s not compulsory. If the function is not overridden, and it is called using
  a derived class object, the base class function will be invoked.
- Remember, never override a non-virtual function.
- Override only virtual or pure virtual functions.
*/