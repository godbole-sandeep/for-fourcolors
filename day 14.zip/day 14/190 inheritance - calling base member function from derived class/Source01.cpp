
/*
If accessing base data members directly is not possible in the derived class,
what is the alternative?
- Invoke the base class member functions from the derived class.
*/