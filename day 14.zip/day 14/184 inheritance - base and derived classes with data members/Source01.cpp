
/*
What will be the size of baseObject?
- The object space of the baseObject comprises a single int data member.
- Hence its size is 4 bytes.

What will be the size of derivedObject?
- The derivedObject includes two data members: its own, m_derivedData, and one inherited
  from the Base class, m_baseData.
- Because each data member is an int, the derivedObject has a size of 8 bytes.
*/
