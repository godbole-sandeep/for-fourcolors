
/*
Why does the program fail to compile the object.Greet() statement?
- The program fails to compile object.Greet() because Greet is not a member function of the AnotherClass.
- It is a member function of the MyClass.
- The two classes are independent.
- Hence, methods of the MyClass class are not available to instances of the AnotherClass.
*/