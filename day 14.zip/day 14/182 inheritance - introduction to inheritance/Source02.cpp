
/*
Why does the compiler now succeed in compiling the object.Greet() statement?
- The program now compiles successfully because an inheritance relationship has been
  set up between the MyClass and AnotherClass.
- The Greet() method of the MyClass class is now accessible to every instance of the AnotherClass.
- In this inheritance relationship, MyClass is known as the base class, parent class,
  general class, or superclass, and AnotherClass is known as the derived class,
  child class, specific class, or subclass.
- It is important to note that the terms base and derived, parent and child,
  general and specific, and super and sub go hand in hand.
- Therefore, if you refer to MyClass as the base class, then you should refer to AnotherClass
  as the derived class.
- An inheritance relationship is also known as an is-a relationship.
*/