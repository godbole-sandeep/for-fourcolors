
/*
What is binding?
- Binding is the process of connecting a function call to its implementation.
- This is accomplished by the linker.

What is static binding?
- Static binding occurs during build time.
- The code above is an example of static binding.
- Static binding is exhibited by Base::Print.

What is the drawback of static binding?
- Static binding can result in inconsistent behavior. Consider a scenario where
  a base class function is called using a base class pointer. If the base class pointer
  is pointing to a derived class object and the base class function is overridden
  in the derived class, the program will still call the base class function.
- This happens because static binding gives priority to the type of the pointer rather than
  the type of the object the pointer is pointing to. As a result, the call invokes the
  base class function instead of the derived class function.
- However, when a call is made using an object of the derived class, the derived class function
  is invoked because the object type takes precedence.
- This inconsistency highlights the drawback of static binding, where the same object
  may invoke different functions depending on whether the call is made via a base class pointer
  or a derived class object.
*/
