
/*
What is the key point to note in the program above?
- An object of a derived class can call member functions of both
  the base class and the derived class.
*/