
/*
What are the key points to note in the program above?
- The Base class's parametric constructor is called in the initializer list
  of the Derived class constructor.
- A limitation of this setup is that the Base class data member is always set to 0.
*/