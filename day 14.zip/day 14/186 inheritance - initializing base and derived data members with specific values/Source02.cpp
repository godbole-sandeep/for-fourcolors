
/*
What are the key points to note in the program above?
- The constructor of the Derived class now takes two parameters.
- One parameter initializes its own data member, and the other
  initializes the Base class data member.
*/