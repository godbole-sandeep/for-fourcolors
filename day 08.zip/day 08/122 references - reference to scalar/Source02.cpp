#include <iostream>

int main() {
	int i = 1;
	int j = i;

	i++;
	std::cout << "Value of i: " << i << std::endl;
	std::cout << "Value of j: " << j << std::endl;

	j += 2;
	std::cout << "Value of i: " << i << std::endl;
	std::cout << "Value of j: " << j << std::endl;

	std::cout << "Address of i: " << &i << std::endl;
	std::cout << "Address of j: " << &j << std::endl;

	return 0;
}

/*
What are the key points to note in the program above?
- Note the changes made to the definition of 'j'.
- The definition now defines 'j' as an alias of 'i'.
- In such a relationship, 'j' is called a reference and 'i' is called the referent.
- The following figure shows a diagram of 'i' and 'j'.
- After initialization of 'j', the state of 'i' and 'j':
		+-----+
	  i	|  1  | j
		+-----+
- After 'i++', state of 'i' and 'j':
		+-----+
	  i	|  2  | j
		+-----+
- After 'j += 2', state of 'i' and 'j':
		+-----+
	  i	|  4  | j
		+-----+

Can a reference, once set up to refer to a particular referent,
be made to refer to another referent?
- No, a reference cannot be made to refer to another referent once it is initialized.
- The reference-referent relationship ends only when the reference ceases to exist.

Can a pointer be reassigned to point to another location?
- A pointer can be reassigned to point to a different location,
  provided the pointer itself is not const.
*/