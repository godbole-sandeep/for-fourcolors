#include <iostream>

int main() {
	int i = 1;
	int j = i;

	i++;
	std::cout << "Value of i: " << i << std::endl;
	std::cout << "Value of j: " << j << std::endl;
	
	j += 2;
	std::cout << "Value of i: " << i << std::endl;
	std::cout << "Value of j: " << j << std::endl;

	std::cout << "Address of i: " << &i << std::endl;
	std::cout << "Address of j: " << &j << std::endl;

	return 0;
}

/*
What are the key points to note in the program above?
- Although 'j' is initialized with the value of 'i', they are two independent variables.
- Their addresses are distinct, which proves that they are separate variables.
- Therefore, changes made to either variable are not reflected in the other.
- The following figure shows a diagram of 'i' and 'j'.
- After initialization, state of 'i' and 'j':
		+-----+     +-----+
	  i	|  1  |	  j |  1  |
		+-----+		+-----+
- After 'i++', state of 'i' and 'j':
		+-----+     +-----+
	  i	|  2  |	  j |  1  |
		+-----+		+-----+
- After 'j += 2', state of 'i' and 'j':
		+-----+     +-----+
	  i	|  2  |	  j |  3 |
		+-----+		+-----+
*/