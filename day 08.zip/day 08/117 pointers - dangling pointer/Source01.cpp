
/*
What is the key point to note in the program above?
- The program results in accessing dangling pointer.
*/
