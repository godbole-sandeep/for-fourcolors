
/*
What are command line arguments?
- Command line arguments are inputs that are passed to a program when
  it is executed from the command line or terminal.

Are 'argc' and 'argv' keywords?
- 'argc' and 'argv' are not keywords.
- They may be replaced with any other names.

What do 'argc' and 'argv' contain?
- 'argc' contains the number of command line arguments passed to the program,
  including the name of the program itself.
- 'argv' is an array of C-style strings (character arrays) that contain the
  actual command line arguments.
- 'argv[0]' is the name of the program, and 'argv[1]' to 'argv[argc-1]' are
  the additional arguments passed to the program.
- Note that the program always receives command line arguments as strings.
- This means that an integer, a real number, a boolean value, a date, or any
  other value is received as a string.
- Therefore, to process such arguments, type conversion from the string to the
  corresponding type is required.

How do you input command line arguments in Visual Studio?
- To input command line arguments in Visual Studio, follow these steps:
  1. Open your project in Visual Studio.
  2. Go to the menu bar and select Project > Properties.
  3. In the Properties window, navigate to Configuration Properties > Debugging.
  4. Find the Command Arguments field.
  5. Enter your command line arguments in the Command Arguments field.
  6. Click OK or Apply to save the changes.
  When you run the program, the specified command line arguments will be passed to it.
*/