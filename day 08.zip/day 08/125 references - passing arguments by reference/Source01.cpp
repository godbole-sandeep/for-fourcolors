void Swap(int u, int v);

int main() {
	int a = 1, b = 2;
	Swap(a, b);
	return 0;
}

void Swap(int u, int v) {
	int t = u;
	u = v;
	v = t;
}

/*
What is the key point to note in the program above?
- Note that the arguments to the Swap function are passed by reference.
- This gives the Swap function direct access to the original variables.
- Hence, Swap manages to perform the swapping of the values of the original variables.
- The following diagrams shows working of the code.
- After 'int a = 1, b = 2;'
		+-----+           +-----+
	  a	|  1  |	        b |  2  |
		+-----+	          +-----+
- When control enters the 'Swap' function, 'u' and 'v' become aliases for 'a' and 'b'.
		+-----+           +-----+
	  a	|  1  | u       b |  2  | v
		+-----+	          +-----+
- After 'int t = u;'
		+-----+           +-----+        +-----+
	  a	|  1  | u       b |  2  | v    t |  1  |
		+-----+	          +-----+        +-----+
- After 'u = v;'
		+-----+           +-----+        +-----+
	  a	|  2  | u       b |  2  | v    t |  1  |
		+-----+	          +-----+        +-----+
- After 'v = t;'
		+-----+           +-----+        +-----+
	  a	|  2  | u       b |  1  | v    t |  1  |
		+-----+	          +-----+        +-----+
- After control exits the 'Swap' function and resumes back in the 'main' function.
		+-----+           +-----+
	  a	|  2  |	        b |  1  |
		+-----+	          +-----+
*/