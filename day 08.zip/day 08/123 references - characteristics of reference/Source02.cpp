
/*
What is an lvalue?
- An lvalue refers to an object that occupies an identifiable location in memory.
- An lvalue allows you to take its address using the address-of operator (&).
- For example, 'i', 'j' and 'k' are lvalues.
- You can take the address of these variables.

What is an rvalue?
- An rvalue refers to a temporary object or literal that does not have a persistent memory
  address and is typically used on the right-hand side of an assignment operation.
- For example, '1' is an rvalue.

What is the key point to note in the program above?
- A non-const reference cannot refer to an rvalue.
*/