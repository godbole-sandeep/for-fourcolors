
/*
What are the characteristics of a reference?
- Initialization of a reference is compulsory.
- Once initialized, it cannot be reassigned to refer to a different referent.
*/
