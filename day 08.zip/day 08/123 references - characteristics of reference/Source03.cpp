
/*
What is the key point to note in the program above?
- A reference cannot be set to null.
- A pointer can be set to null.
*/