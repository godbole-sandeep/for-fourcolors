
/*
What is an array of pointers?
- An array of pointers is an array where each element is a pointer to some type of data.
- For example, in the above program 'ptrArray' is an array of pointers. 

What are the key points to note in the program above?
- Following points are to be noted in the above program:
  1. How each pointer is allocated memory on the freestore.
  2. How the memory allocated to each pointer is accessed.
  3. How the memory allocated to each pointer is released.

What do the expressions 'ptrArray', 'ptrArray[i]', and '*ptrArray[i]' result in?
- Refer to the accompanying 'array-of-pointers.png' for reference.
- The expression 'ptrArray' results in 100, which is the base address of the entire array.
- The expression 'ptrArray[i]' results in 200, 208, or 228, depending on the value of 'i'.
- These addresses (200, 208, and 228) are the base addresses of the allocated memory for
  each pointer.
- The expression '*ptrArray[i]' accesses the value of the allocated memory,
  such as 0, 10, or 20, depending on the value of 'i'.
*/