
/*
What is the key point to note in the program above?
- A const-reference can refer to an rvalue.
*/