
/*
What are the key points to note in the program above?
- A non-const reference can refer only to a non-const referent.
- A const reference can refer to both const and non-const referents.
*/
