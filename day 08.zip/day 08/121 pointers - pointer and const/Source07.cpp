int main() {
	const int u = 1;			// 1

	int* const p = &u;			// 2

	u = u + 1;					// 3

	*p = *p + 1;				// 4

	int v = 2;					// 5

	p = &v;						// 6

	return 0;
}

/*
Which expressions do you believe will successfully compile, and which will fail?
- Because this is a quiz question, the answer is not provided here.
*/