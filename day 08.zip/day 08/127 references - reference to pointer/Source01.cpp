void AllocateInt(int* ptr);

int main() {
	int* pa = nullptr;
	AllocateInt(pa);
	delete pa;
	pa = nullptr;
	return 0;
}

void AllocateInt(int* ptr) {
	ptr = new int;
}


/*
What is the key point to note in the program above?
- The `ptrRef` is known as a reference to a pointer.
- It is an alias for the pointer.

What will be the value of 'pa' after the execution of 'AllocateInt'?
- This is a quiz, so the answer is not discussed here.
*/