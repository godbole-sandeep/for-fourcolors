int var = 1;

int& GetVarReference();

int main() {
	int& varRef = GetVarReference();
	varRef = 5;

	int var2 = GetVarReference();
	var2 = 10;

	return 0;
}

int& GetVarReference() {
	return var;
}

/*
What is the key point to note in the program above?
- `GetVarReference` is attempting to return a reference to a local variable.
- This is not a good coding practice.
- This is because local variables cease to exist as soon as control flows out of the function.
- Hence, once control flows out of `GetVarReference`, the `var` variable will be released.
- Thus, returning a reference to `var` is like returning a reference to a released variable.
- This makes `varRef` a dangling reference.
*/
