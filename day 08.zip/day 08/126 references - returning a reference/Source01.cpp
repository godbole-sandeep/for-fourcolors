int var = 1;

int& GetVarReference();

int main() {
	int& varRef = GetVarReference();
	varRef = 5;

	int var2 = GetVarReference();
	var2 = 10;

	return 0;
}

int& GetVarReference() {
	return var;
}

/*
What is the key point to note in the program above?
- The 'GetVarReference' function returns a reference to the global variable 'var'.
- Although 'GetVarReference' returns a reference, it is not compulsory for the
  recipient variable to be a reference.
- For example, 'var2' is not a reference, yet it can still hold the return value
  of 'GetVarReference'.
*/