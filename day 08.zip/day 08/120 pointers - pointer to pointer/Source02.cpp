void AllocateInt(int* pn) {
	pn = new int;
}

int main() {
	int* pa = nullptr;
	AllocateInt(pa);
	return 0;
}

/*
What will be the value of 'pa' after the execution of 'AllocateInt'?
- This is a quiz, so the answer is not discussed here.
*/
