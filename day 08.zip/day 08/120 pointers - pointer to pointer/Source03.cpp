void AllocateInt(int* pn) {
	pn = new int;
}

int main() {
	int* pa = nullptr;
	AllocateInt(pa);
	return 0;
}

/*
Why did the pointer 'pa' contain a null value after the execution of AllocateInt
in the previous program?
- In the previous program, the pointer 'pa' contained a null value after the
  execution of 'AllocateInt' because the function 'AllocateInt' was only modifying
  a local copy of the pointer, not the original pointer.
- As a result, the change did not affect the pointer 'pa' in the 'main' function.

Why in this program, 'pa' gets assigned the address?
- By passing the address of 'pa' ('&pa') to 'AllocateInt', the function can modify
  the original pointer 'pa' in the 'main' function.
- This is because 'pn' in the function actually refers to 'pa'.
*/
