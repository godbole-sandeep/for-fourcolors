
/*
Does a pointer have an address?
- Yes, a pointer has an address.
- Since a pointer is a variable and all variables have addresses,
  a pointer also has an address.

How do you obtain the address of a pointer?
- To obtain the address of a pointer, use the same method as with other variables.
- Prefix the address-of operator (&) before the pointer variable.
- For example, if 'ptr' is a pointer, then '&ptr' results in the address of 'ptr'.

How do you define a pointer variable that holds the address of a pointer?
- To define a pointer variable that holds the address of another pointer,
  you need to use a double asterisk (**).
- For example, note the use of the double asterisk in 'int** ptrToPtr = &ptr;'.
*/