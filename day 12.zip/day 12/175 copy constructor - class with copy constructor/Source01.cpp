
/*
What is a copy constructor?
- A copy constructor is a special constructor that initializes
  a new object as a copy of an existing object.
*/