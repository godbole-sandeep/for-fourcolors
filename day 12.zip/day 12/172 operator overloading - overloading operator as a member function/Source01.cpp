
/*
What is operator overloading?
- Operator overloading is a feature of C++.
- It allows developers to define custom behaviors for operators
  when they are used with user-defined types.

What are the limitations of operator overloading?
- Operator overloading does not allow changes to the operator precedence table.
- As a result, new operators cannot be added.
- Some operators (e.g.::,., sizeof, typeid,?:) cannot be overloaded.
- Most operators can be implemented in either member or global function form.
- Some operators, such as (), [], and (casting), must only be implemented as member functions.
- It is recommended to use the global function form whenever it is supported.
*/