
/*
What is the key point to note in the program above?
- Note that the constructor cannot be invoked explicitly;
  however, an explicit call to the destructor is permissible.
- Usually we donot call destructor explicitly.
*/