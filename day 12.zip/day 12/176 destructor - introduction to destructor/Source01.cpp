
/*
What is a destructor?
- A destructor is a special member function that is automatically called
  when an object goes out of scope.
*/