
/*
What are the key points to note in the program above?
- When a class is not written with a destructor,
  compiler writes the destructor for that class.
- This destructor doesn't do anything.
- If the developer provides a destructor to a class,
  the compiler no longer provides it.
- In short, the destructor always exist in a class whether written
  explicitly or provided implicitly.
*/