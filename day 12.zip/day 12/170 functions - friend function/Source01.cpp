
/*
What is the key point to note in the program above?
- Private members of a class are not accessible to non-members.
*/