
/*
What is a friend function?
- A friend function is a non-member function that has access
  to private members of a class.

How do you declare a function as a friend function of a class?
- To declare a function as a friend of a class, you specify the function's
  prototype in the class definition using the 'friend' keyword.
- This grants the function access to the private and protected members of the class.
- The declaration can be placed anywhere within the class.
*/