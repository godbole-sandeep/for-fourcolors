
/*
What is a resource?
- A resource is an aid that an object needs to accomplish its functions.

When can an object acqire a resource?
- An object may acquire a resource at any point throughout its lifespan.
- One possible scenario is at the start of the object's lifecycle,
  in the constructor.
- However, it is not necessary for an object to acquire resources
  in the constructor.
- It can also acquire resources in other functions.

If an object acquires a resource, what complementary action should
the object not forget to perform?
- The object should not forget to release resources.
- This task can occur at any time throughout an object's existence.
- However, it must be completed before the object is released.
- Failure to do so risks leaking the resource.
- The last opportunity to release resources is in the destructor.
- Therefore, the final point where you can write resource release code
  is in the destructor.

Will writing an empty destructor release resources?
- No, writing an empty destructor will not release resources.
- Therefore, the destructor must include code to release resources.
*/