
/*
Why does a program fail to compile?
- The compiler fails to evaluate c = a + b since a, b, and c are 
  objects of user defined type 'Integer'.
- Since Integer is a user-defined type, the compiler cannot determine which
  member of 'a' should be added to which member of 'b' and which member of
  'c' should receive the result.
- As a result, the compiler returns an error while evaluating the
  expression 'a + b'.
*/