
/*
What are the key points to note in the program above?
- It appears that no constructor was called during the construction of
  the 'b' object, however this is not true.
- While creating the 'b' object, the compiler-supplied copy constructor is called.
- The compiler-supplied copy constructor simply copies the rhs object onto
  the lhs object byte by byte.
- Copy constructor always exist in the class.
*/
